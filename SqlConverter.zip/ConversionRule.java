package com.converter.rule;

import java.util.regex.Pattern;

/**
 * ConversionRule
 * One named rewrite rule: a compiled regex pattern + replacement string.
 *
 * @param id          Short unique ID  e.g. "NVL_001"
 * @param category    Grouping label   e.g. "NULL Functions"
 * @param description Human description: "NVL(a,b) → ISNULL(a,b)"
 * @param sybaseForm  Example Sybase syntax shown in report
 * @param mssqlForm   Example MSSQL  syntax shown in report
 * @param pattern     Compiled regex
 * @param replacement Replacement string (may contain $1, $2 back-refs)
 */
public record ConversionRule(
        String  id,
        String  category,
        String  description,
        String  sybaseForm,
        String  mssqlForm,
        Pattern pattern,
        String  replacement
) {
    /** Apply this rule to the given SQL and return the result. */
    public String apply(String sql) {
        try {
            return pattern.matcher(sql).replaceAll(replacement);
        } catch (Exception ex) {
            // Never crash the whole pipeline on a single rule failure
            return sql;
        }
    }

    /** True if this rule would match anything in the given SQL. */
    public boolean matches(String sql) {
        return pattern.matcher(sql).find();
    }
}
