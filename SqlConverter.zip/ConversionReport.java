package com.converter.model;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * ConversionReport — summary statistics + all individual results for a batch run.
 */
public class ConversionReport {

    private final List<ConversionResult> results;
    private final String                 generatedAt;
    private final String                 sourceFile;

    public ConversionReport(List<ConversionResult> results,
                            String generatedAt,
                            String sourceFile) {
        this.results     = results;
        this.generatedAt = generatedAt;
        this.sourceFile  = sourceFile;
    }

    public List<ConversionResult> getResults()     { return results;     }
    public String                 getGeneratedAt() { return generatedAt; }
    public String                 getSourceFile()  { return sourceFile;  }

    public int getTotalQueries()   { return results.size(); }
    public int getChangedCount()   { return (int) results.stream().filter(ConversionResult::isChanged).count(); }
    public int getUnchangedCount() { return getTotalQueries() - getChangedCount(); }

    /** How many queries had each rule fired, sorted by frequency descending. */
    public Map<String, Long> getRuleFrequency() {
        return results.stream()
            .flatMap(r -> r.getAppliedRules().stream())
            .collect(Collectors.groupingBy(
                rm -> rm.description(),
                Collectors.counting()
            ))
            .entrySet().stream()
            .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
            .collect(Collectors.toMap(
                Map.Entry::getKey,
                Map.Entry::getValue,
                (a, b) -> a,
                java.util.LinkedHashMap::new
            ));
    }
}
