package com.converter.engine;

import com.converter.model.ConversionResult;
import com.converter.rule.ConversionRule;
import com.converter.rule.RuleMatch;

import java.util.*;
import java.util.regex.*;

/**
 * ══════════════════════════════════════════════════════════════════════════════
 *  SybaseToMsSqlConverter
 *  Converts Sybase IQ SQL dialect → Microsoft SQL Server (T-SQL)
 * ══════════════════════════════════════════════════════════════════════════════
 *
 *  Covers 50+ conversion rules across 10 categories:
 *
 *   1.  NULL Functions        — NVL, IFNULL, NULLIF (same)
 *   2.  String Functions      — LENGTH→LEN, SUBSTR→SUBSTRING, LOCATE→CHARINDEX,
 *                               TRIM→LTRIM(RTRIM()), INSTR, LPAD, RPAD,
 *                               INITCAP, string concat ||→+
 *   3.  Date / Time           — NOW(), SYSDATE, TODAY(), DATEFORMAT→FORMAT,
 *                               ADD_MONTHS, MONTHS_BETWEEN, TRUNC, TO_CHAR,
 *                               TO_DATE, DATEPART (compatible), DAYS()
 *   4.  Math Functions        — MOD→%, REMAINDER→%, same: ROUND/FLOOR/CEILING/ABS
 *   5.  Aggregate Functions   — LIST→STRING_AGG (with ORDER BY variant)
 *   6.  Type Conversion       — CONVERT compatible, TO_NUMBER→CAST, STRING type,
 *                               LONG VARCHAR, UNSIGNED INT
 *   7.  Control Flow          — DECODE→CASE WHEN (recursive, N args)
 *   8.  Top-N / Pagination    — FETCH FIRST n ROWS ONLY → TOP n,
 *                               LIMIT n → TOP n
 *   9.  CTE / Recursive       — WITH RECURSIVE → WITH
 *  10.  Reserved Words        — LEVEL column alias, RANK (same), etc.
 *
 *  Usage:
 *      SybaseToMsSqlConverter conv = new SybaseToMsSqlConverter();
 *      ConversionResult result = conv.convert(1, "Q001", sybaseSql);
 *      System.out.println(result.getConvertedSql());
 */
public class SybaseToMsSqlConverter {

    // ── Ordered rule list ──────────────────────────────────────────────────────
    // Rules are applied in declaration order.
    // More specific / longer patterns must come BEFORE shorter ones.
    private final List<ConversionRule> rules;

    public SybaseToMsSqlConverter() {
        rules = buildAllRules();
    }

    /** Return a read-only view of all registered rules (for documentation / UI). */
    public List<ConversionRule> getAllRules() {
        return Collections.unmodifiableList(rules);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  PUBLIC CONVERT API
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Convert a single Sybase IQ SQL string to MS SQL T-SQL.
     *
     * @param queryIndex  1-based index (for reporting)
     * @param queryLabel  Short label e.g. "Q001"
     * @param sybaseSql   Raw Sybase IQ SQL string
     * @return            ConversionResult with converted SQL + applied rules log
     */
    public ConversionResult convert(int queryIndex, String queryLabel, String sybaseSql) {
        if (sybaseSql == null || sybaseSql.isBlank()) {
            return new ConversionResult(queryIndex, queryLabel, sybaseSql, sybaseSql, List.of());
        }

        String          sql          = sybaseSql;
        List<RuleMatch> appliedRules = new ArrayList<>();

        // ── Pass 1: Simple regex rules (order-sensitive) ───────────────────────
        for (ConversionRule rule : rules) {
            if (rule.matches(sql)) {
                String converted = rule.apply(sql);
                if (!converted.equals(sql)) {
                    appliedRules.add(new RuleMatch(
                        rule.id(), rule.category(), rule.description(),
                        rule.sybaseForm(), rule.mssqlForm()
                    ));
                    sql = converted;
                }
            }
        }

        // ── Pass 2: Complex structural rewrites (need custom parsers) ──────────

        // DECODE( expr, v1,r1, v2,r2, …, default ) → CASE WHEN … END
        String afterDecode = rewriteDecode(sql);
        if (!afterDecode.equals(sql)) {
            appliedRules.add(new RuleMatch(
                "DEC_001", "Control Flow",
                "DECODE(expr,v1,r1,...) → CASE WHEN expr=v1 THEN r1 ... END",
                "DECODE(status,'A','Active','I','Inactive','Unknown')",
                "CASE WHEN status='A' THEN 'Active' WHEN status='I' THEN 'Inactive' ELSE 'Unknown' END"
            ));
            sql = afterDecode;
        }

        // LIST( col, sep ) → STRING_AGG( col, sep )
        String afterList = rewriteListAggregate(sql);
        if (!afterList.equals(sql)) {
            appliedRules.add(new RuleMatch(
                "AGG_001", "Aggregate Functions",
                "LIST(col, sep) / LIST(col ORDER BY col, sep) → STRING_AGG(col,sep) WITHIN GROUP (ORDER BY col)",
                "LIST(account_id, ', ')",
                "STRING_AGG(account_id, ', ')"
            ));
            sql = afterList;
        }

        // TRIM(x) → LTRIM(RTRIM(x))  — needs paren balancer
        String afterTrim = rewriteTrim(sql);
        if (!afterTrim.equals(sql)) {
            appliedRules.add(new RuleMatch(
                "STR_005", "String Functions",
                "TRIM(expr) → LTRIM(RTRIM(expr))",
                "TRIM(first_name)",
                "LTRIM(RTRIM(first_name))"
            ));
            sql = afterTrim;
        }

        // FETCH FIRST n ROWS ONLY / LIMIT n → TOP n  (SELECT rewrite)
        String afterTop = rewriteTopN(sql);
        if (!afterTop.equals(sql)) {
            appliedRules.add(new RuleMatch(
                "PAG_001", "Pagination / Top-N",
                "FETCH FIRST n ROWS ONLY / LIMIT n → SELECT TOP n …",
                "SELECT … FROM … FETCH FIRST 10 ROWS ONLY",
                "SELECT TOP 10 … FROM …"
            ));
            sql = afterTop;
        }

        // LPAD / RPAD — multi-arg (already handled in regex but double-pass for safety)
        // Pass 3: final cleanup
        sql = finalCleanup(sql);

        return new ConversionResult(queryIndex, queryLabel, sybaseSql, sql, appliedRules);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  RULE DEFINITIONS
    // ══════════════════════════════════════════════════════════════════════════

    private List<ConversionRule> buildAllRules() {
        List<ConversionRule> r = new ArrayList<>();
        int F = Pattern.CASE_INSENSITIVE | Pattern.DOTALL;

        // ──────────────────────────────────────────────────────────────────────
        //  CATEGORY 1 — NULL Functions
        // ──────────────────────────────────────────────────────────────────────

        r.add(rule("NULL_001", "NULL Functions",
            "NVL(a,b) → ISNULL(a,b)",
            "NVL(col, 0)", "ISNULL(col, 0)",
            "\\bNVL\\s*\\(", F, "ISNULL("));

        r.add(rule("NULL_002", "NULL Functions",
            "IFNULL(a,b) → ISNULL(a,b)",
            "IFNULL(col, 0)", "ISNULL(col, 0)",
            "\\bIFNULL\\s*\\(", F, "ISNULL("));

        r.add(rule("NULL_003", "NULL Functions",
            "NVL2(expr,val_if_notnull,val_if_null) → IIF(expr IS NOT NULL, val_if_notnull, val_if_null)",
            "NVL2(col,'Y','N')", "IIF(col IS NOT NULL,'Y','N')",
            "\\bNVL2\\s*\\(([^,]+),([^,]+),([^)]+)\\)", F,
            "IIF($1 IS NOT NULL, $2, $3)"));

        // NULLIF is identical in both — no change, but document it
        // COALESCE is identical — no change

        // ──────────────────────────────────────────────────────────────────────
        //  CATEGORY 2 — String Functions
        // ──────────────────────────────────────────────────────────────────────

        // LENGTH → LEN
        r.add(rule("STR_001", "String Functions",
            "LENGTH(expr) → LEN(expr)",
            "LENGTH(name)", "LEN(name)",
            "\\bLENGTH\\s*\\(", F, "LEN("));

        // SUBSTR → SUBSTRING  (both 2-arg and 3-arg forms)
        r.add(rule("STR_002", "String Functions",
            "SUBSTR(str,pos,len) → SUBSTRING(str,pos,len)",
            "SUBSTR(name,1,3)", "SUBSTRING(name,1,3)",
            "\\bSUBSTR\\s*\\(", F, "SUBSTRING("));

        // LOCATE(substr, str [, start]) → CHARINDEX(substr, str [, start])
        // Note: Sybase LOCATE(sub, str) = CHARINDEX(sub, str) — same arg order!
        r.add(rule("STR_003", "String Functions",
            "LOCATE(substr, str) → CHARINDEX(substr, str)",
            "LOCATE('X', col)", "CHARINDEX('X', col)",
            "\\bLOCATE\\s*\\(", F, "CHARINDEX("));

        // INSTR(str, substr [, pos, nth]) → CHARINDEX(substr, str [, pos])
        // Arg order is REVERSED in INSTR vs CHARINDEX!
        r.add(rule("STR_004", "String Functions",
            "INSTR(str, substr) → CHARINDEX(substr, str)  [args reversed]",
            "INSTR(col,'X')", "CHARINDEX('X',col)",
            "\\bINSTR\\s*\\(([^,]+),([^,)]+)\\)", F, "CHARINDEX($2, $1)"));

        // TRIM — handled in rewriteTrim() below (needs paren balancer)
        // Marker rule so it shows up in the rules list
        r.add(rule("STR_005", "String Functions",
            "TRIM(expr) → LTRIM(RTRIM(expr))",
            "TRIM(col)", "LTRIM(RTRIM(col))",
            "(?!x)x", F, ""));   // dummy — rewriteTrim() does the actual work

        // String concatenation  ||  →  +
        r.add(rule("STR_006", "String Functions",
            "|| (string concat) → +",
            "first || ' ' || last", "first + ' ' + last",
            "\\|\\|", F, " + "));

        // LPAD(str, n, pad) → RIGHT(REPLICATE(pad,n)+str, n)
        r.add(rule("STR_007", "String Functions",
            "LPAD(str,n,pad) → RIGHT(REPLICATE(pad,n)+CAST(str AS VARCHAR),n)",
            "LPAD(id,10,'0')", "RIGHT(REPLICATE('0',10)+CAST(id AS VARCHAR),10)",
            "\\bLPAD\\s*\\(([^,]+),([^,]+),([^)]+)\\)", F,
            "RIGHT(REPLICATE($3, $2) + CAST($1 AS VARCHAR), $2)"));

        // RPAD(str, n, pad) → LEFT(CAST(str AS VARCHAR)+REPLICATE(pad,n), n)
        r.add(rule("STR_008", "String Functions",
            "RPAD(str,n,pad) → LEFT(CAST(str AS VARCHAR)+REPLICATE(pad,n),n)",
            "RPAD(name,20,' ')", "LEFT(CAST(name AS VARCHAR)+REPLICATE(' ',20),20)",
            "\\bRPAD\\s*\\(([^,]+),([^,]+),([^)]+)\\)", F,
            "LEFT(CAST($1 AS VARCHAR) + REPLICATE($3, $2), $2)"));

        // INITCAP — no T-SQL equivalent; wrap in comment
        r.add(rule("STR_009", "String Functions",
            "INITCAP(expr) — no T-SQL native; replaced with comment placeholder",
            "INITCAP(name)", "/*TODO:INITCAP*/ UPPER(name)",
            "\\bINITCAP\\s*\\(", F, "/*TODO:INITCAP*/ UPPER("));

        // CHAR_LENGTH → LEN
        r.add(rule("STR_010", "String Functions",
            "CHAR_LENGTH(expr) → LEN(expr)",
            "CHAR_LENGTH(col)", "LEN(col)",
            "\\bCHAR_LENGTH\\s*\\(", F, "LEN("));

        // REPEAT(str, n) → REPLICATE(str, n)
        r.add(rule("STR_011", "String Functions",
            "REPEAT(str,n) → REPLICATE(str,n)",
            "REPEAT('X',5)", "REPLICATE('X',5)",
            "\\bREPEAT\\s*\\(", F, "REPLICATE("));

        // SPACE(n) — same in both (no change needed)

        // STRTOINT → CAST(... AS INT)
        r.add(rule("STR_012", "String Functions",
            "STRTOINT(str) → CAST(str AS INT)",
            "STRTOINT(col)", "CAST(col AS INT)",
            "\\bSTRTOINT\\s*\\(([^)]+)\\)", F, "CAST($1 AS INT)"));

        // ──────────────────────────────────────────────────────────────────────
        //  CATEGORY 3 — Date / Time Functions
        // ──────────────────────────────────────────────────────────────────────

        // NOW() → GETDATE()
        r.add(rule("DT_001", "Date/Time Functions",
            "NOW() → GETDATE()",
            "NOW()", "GETDATE()",
            "\\bNOW\\s*\\(\\s*\\)", F, "GETDATE()"));

        // SYSDATE → GETDATE()
        r.add(rule("DT_002", "Date/Time Functions",
            "SYSDATE → GETDATE()",
            "SYSDATE", "GETDATE()",
            "\\bSYSDATE\\b", F, "GETDATE()"));

        // TODAY() → CAST(GETDATE() AS DATE)
        r.add(rule("DT_003", "Date/Time Functions",
            "TODAY() → CAST(GETDATE() AS DATE)",
            "TODAY()", "CAST(GETDATE() AS DATE)",
            "\\bTODAY\\s*\\(\\s*\\)", F, "CAST(GETDATE() AS DATE)"));

        // DATEFORMAT(date, fmt) → FORMAT(date, fmt)
        r.add(rule("DT_004", "Date/Time Functions",
            "DATEFORMAT(date, fmt) → FORMAT(date, fmt)",
            "DATEFORMAT(dt,'YYYY-MM-DD')", "FORMAT(dt,'yyyy-MM-dd')",
            "\\bDATEFORMAT\\s*\\(", F, "FORMAT("));

        // ADD_MONTHS(date, n) → DATEADD(MONTH, n, date)
        r.add(rule("DT_005", "Date/Time Functions",
            "ADD_MONTHS(date,n) → DATEADD(MONTH,n,date)",
            "ADD_MONTHS(dt,3)", "DATEADD(MONTH,3,dt)",
            "\\bADD_MONTHS\\s*\\(([^,]+),([^)]+)\\)", F,
            "DATEADD(MONTH, $2, $1)"));

        // MONTHS_BETWEEN(d1, d2) → DATEDIFF(MONTH, d2, d1)
        r.add(rule("DT_006", "Date/Time Functions",
            "MONTHS_BETWEEN(d1,d2) → DATEDIFF(MONTH,d2,d1)",
            "MONTHS_BETWEEN(dt1,dt2)", "DATEDIFF(MONTH,dt2,dt1)",
            "\\bMONTHS_BETWEEN\\s*\\(([^,]+),([^)]+)\\)", F,
            "DATEDIFF(MONTH, $2, $1)"));

        // TRUNC(date) → CAST(date AS DATE)
        r.add(rule("DT_007", "Date/Time Functions",
            "TRUNC(date) → CAST(date AS DATE)  [date truncation only]",
            "TRUNC(dt)", "CAST(dt AS DATE)",
            "\\bTRUNC\\s*\\(([^)]+)\\)", F, "CAST($1 AS DATE)"));

        // TO_CHAR(date, fmt) → FORMAT(date, fmt)
        r.add(rule("DT_008", "Date/Time Functions",
            "TO_CHAR(date, fmt) → FORMAT(date, fmt)",
            "TO_CHAR(dt,'YYYY-MM')", "FORMAT(dt,'yyyy-MM')",
            "\\bTO_CHAR\\s*\\(", F, "FORMAT("));

        // TO_DATE(str, fmt) → TRY_CONVERT(DATE, str, 120)
        r.add(rule("DT_009", "Date/Time Functions",
            "TO_DATE(str, fmt) → TRY_CONVERT(DATE, str, 120)",
            "TO_DATE(col,'YYYY-MM-DD')", "TRY_CONVERT(DATE, col, 120)",
            "\\bTO_DATE\\s*\\(([^,]+),[^)]+\\)", F,
            "TRY_CONVERT(DATE, $1, 120)"));

        // TO_TIMESTAMP → TRY_CONVERT(DATETIME, str, 120)
        r.add(rule("DT_010", "Date/Time Functions",
            "TO_TIMESTAMP(str) → TRY_CONVERT(DATETIME, str, 120)",
            "TO_TIMESTAMP(col)", "TRY_CONVERT(DATETIME, col, 120)",
            "\\bTO_TIMESTAMP\\s*\\(([^)]+)\\)", F,
            "TRY_CONVERT(DATETIME, $1, 120)"));

        // DAYS(date) — Sybase IQ days-since-epoch → DATEDIFF(DAY, '1900-01-01', date)
        r.add(rule("DT_011", "Date/Time Functions",
            "DAYS(date) → DATEDIFF(DAY,'1900-01-01',date)  [days since epoch]",
            "DAYS(dt)", "DATEDIFF(DAY,'1900-01-01',dt)",
            "\\bDAYS\\s*\\(([^)]+)\\)", F,
            "DATEDIFF(DAY, '1900-01-01', $1)"));

        // YMD(y,m,d) → DATEFROMPARTS(y,m,d)
        r.add(rule("DT_012", "Date/Time Functions",
            "YMD(y,m,d) → DATEFROMPARTS(y,m,d)",
            "YMD(2024,1,15)", "DATEFROMPARTS(2024,1,15)",
            "\\bYMD\\s*\\(", F, "DATEFROMPARTS("));

        // DATEADD, DATEDIFF, YEAR, MONTH, DAY, DATEPART — all compatible; no change

        // ──────────────────────────────────────────────────────────────────────
        //  CATEGORY 4 — Math Functions
        // ──────────────────────────────────────────────────────────────────────

        // MOD(a,b) → (a % b)
        r.add(rule("MATH_001", "Math Functions",
            "MOD(a,b) → (a % b)",
            "MOD(id,2)", "(id % 2)",
            "\\bMOD\\s*\\(([^,]+),([^)]+)\\)", F, "($1 % $2)"));

        // REMAINDER(a,b) → (a % b)
        r.add(rule("MATH_002", "Math Functions",
            "REMAINDER(a,b) → (a % b)",
            "REMAINDER(val,3)", "(val % 3)",
            "\\bREMAINDER\\s*\\(([^,]+),([^)]+)\\)", F, "($1 % $2)"));

        // EXP, LOG, LOG10, SQRT, POWER — identical in both DBs

        // SIGN — identical

        // RAND — identical

        // TO_NUMBER(str) → TRY_CAST(str AS DECIMAL(18,4))
        r.add(rule("MATH_003", "Math Functions",
            "TO_NUMBER(str) → TRY_CAST(str AS DECIMAL(18,4))",
            "TO_NUMBER(col)", "TRY_CAST(col AS DECIMAL(18,4))",
            "\\bTO_NUMBER\\s*\\(([^)]+)\\)", F, "TRY_CAST($1 AS DECIMAL(18,4))"));

        // INT(x) — Sybase truncates toward zero; same as CAST(x AS INT)
        r.add(rule("MATH_004", "Math Functions",
            "INT(x) → CAST(x AS INT)",
            "INT(3.7)", "CAST(3.7 AS INT)",
            "\\bINT\\s*\\(([^)]+)\\)(?!\\s+AS)", F, "CAST($1 AS INT)"));

        // ──────────────────────────────────────────────────────────────────────
        //  CATEGORY 5 — Data Types
        // ──────────────────────────────────────────────────────────────────────

        // STRING type → VARCHAR(MAX)
        r.add(rule("TYPE_001", "Data Types",
            "STRING data type → VARCHAR(MAX)",
            "col STRING", "col VARCHAR(MAX)",
            "\\bSTRING\\b(?!\\s*_AGG|\\s*_SPLIT)", F, "VARCHAR(MAX)"));

        // LONG VARCHAR → VARCHAR(MAX)
        r.add(rule("TYPE_002", "Data Types",
            "LONG VARCHAR → VARCHAR(MAX)",
            "col LONG VARCHAR", "col VARCHAR(MAX)",
            "\\bLONG\\s+VARCHAR\\b", F, "VARCHAR(MAX)"));

        // LONG BINARY → VARBINARY(MAX)
        r.add(rule("TYPE_003", "Data Types",
            "LONG BINARY → VARBINARY(MAX)",
            "col LONG BINARY", "col VARBINARY(MAX)",
            "\\bLONG\\s+BINARY\\b", F, "VARBINARY(MAX)"));

        // UNSIGNED INT → INT  (SQL Server has no UNSIGNED)
        r.add(rule("TYPE_004", "Data Types",
            "UNSIGNED INT → INT  (SQL Server has no unsigned; use BIGINT for safety)",
            "col UNSIGNED INT", "col BIGINT",
            "\\bUNSIGNED\\s+INT\\b", F, "BIGINT"));

        // UNSIGNED BIGINT → BIGINT
        r.add(rule("TYPE_005", "Data Types",
            "UNSIGNED BIGINT → BIGINT",
            "col UNSIGNED BIGINT", "col BIGINT",
            "\\bUNSIGNED\\s+BIGINT\\b", F, "BIGINT"));

        // BIT VARYING → VARBINARY
        r.add(rule("TYPE_006", "Data Types",
            "BIT VARYING(n) → VARBINARY(n)",
            "col BIT VARYING(8)", "col VARBINARY(8)",
            "\\bBIT\\s+VARYING\\b", F, "VARBINARY"));

        // SMALLDATETIME — compatible; no change

        // ──────────────────────────────────────────────────────────────────────
        //  CATEGORY 6 — Type Conversion Functions
        // ──────────────────────────────────────────────────────────────────────

        // CONVERT is compatible in both (same syntax: CONVERT(type, expr, style))

        // CAST is compatible in both

        // INTTOSTR(n) → CAST(n AS VARCHAR)
        r.add(rule("CONV_001", "Type Conversion",
            "INTTOSTR(n) → CAST(n AS VARCHAR)",
            "INTTOSTR(id)", "CAST(id AS VARCHAR)",
            "\\bINTTOSTR\\s*\\(([^)]+)\\)", F, "CAST($1 AS VARCHAR)"));

        // STRING(expr) — Sybase cast-to-string → CAST(expr AS VARCHAR)
        // (only when STRING is used as a function, not as a type)
        r.add(rule("CONV_002", "Type Conversion",
            "STRING(expr) as cast-function → CAST(expr AS VARCHAR)",
            "STRING(amount)", "CAST(amount AS VARCHAR)",
            "\\bSTRING\\s*\\(([^)]+)\\)", F, "CAST($1 AS VARCHAR)"));

        // ──────────────────────────────────────────────────────────────────────
        //  CATEGORY 7 — Control Flow  (DECODE handled separately)
        // ──────────────────────────────────────────────────────────────────────

        // IF(cond, val1, val2) → IIF(cond, val1, val2)
        r.add(rule("CF_001", "Control Flow",
            "IF(cond,val1,val2) → IIF(cond,val1,val2)",
            "IF(a>b, a, b)", "IIF(a>b, a, b)",
            "\\bIF\\s*\\(", F, "IIF("));

        // ──────────────────────────────────────────────────────────────────────
        //  CATEGORY 8 — CTE / Recursive
        // ──────────────────────────────────────────────────────────────────────

        // WITH RECURSIVE → WITH
        r.add(rule("CTE_001", "CTE / Recursive",
            "WITH RECURSIVE → WITH  (SQL Server CTEs are recursive by default)",
            "WITH RECURSIVE cte AS (…)", "WITH cte AS (…)",
            "\\bWITH\\s+RECURSIVE\\b", F, "WITH"));

        // ──────────────────────────────────────────────────────────────────────
        //  CATEGORY 9 — Reserved Word Conflicts
        // ──────────────────────────────────────────────────────────────────────

        // LEVEL column alias — reserved in SQL Server when using connect-by style
        // Safe to rename only when used as a bare column alias after AS
        r.add(rule("RES_001", "Reserved Words",
            "AS LEVEL → AS emp_level  (LEVEL is reserved in SQL Server hierarchical queries)",
            "0 AS LEVEL", "0 AS emp_level",
            "\\bAS\\s+LEVEL\\b", F, "AS emp_level"));

        // ──────────────────────────────────────────────────────────────────────
        //  CATEGORY 10 — Miscellaneous
        // ──────────────────────────────────────────────────────────────────────

        // GETDATE() in Sybase is same as MSSQL — no change needed but document
        // ISNULL — same in both

        // ROWNUM (Oracle-style sometimes used in Sybase IQ)
        r.add(rule("MISC_001", "Miscellaneous",
            "ROWNUM → ROW_NUMBER() OVER (ORDER BY (SELECT NULL))",
            "WHERE ROWNUM <= 10", "WHERE ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) <= 10",
            "\\bROWNUM\\b", F, "ROW_NUMBER() OVER (ORDER BY (SELECT NULL))"));

        // EXECUTE IMMEDIATE → EXEC / sp_executesql
        r.add(rule("MISC_002", "Miscellaneous",
            "EXECUTE IMMEDIATE → EXEC  (dynamic SQL)",
            "EXECUTE IMMEDIATE 'SELECT 1'", "EXEC('SELECT 1')",
            "\\bEXECUTE\\s+IMMEDIATE\\s+'([^']+)'", F, "EXEC('$1')"));

        // IDENTITY column property
        r.add(rule("MISC_003", "Miscellaneous",
            "DEFAULT AUTOINCREMENT → IDENTITY(1,1)",
            "id INT DEFAULT AUTOINCREMENT", "id INT IDENTITY(1,1)",
            "\\bDEFAULT\\s+AUTOINCREMENT\\b", F, "IDENTITY(1,1)"));

        // GLOBAL TEMPORARY TABLE → syntax note
        r.add(rule("MISC_004", "Miscellaneous",
            "CREATE GLOBAL TEMPORARY TABLE → CREATE TABLE #temp  (temp table in SQL Server)",
            "CREATE GLOBAL TEMPORARY TABLE t", "CREATE TABLE #t /*was: GLOBAL TEMPORARY*/",
            "\\bCREATE\\s+GLOBAL\\s+TEMPORARY\\s+TABLE\\s+(\\w+)", F,
            "CREATE TABLE #$1 /*was: GLOBAL TEMPORARY TABLE*/"));

        // LOCAL TEMPORARY TABLE
        r.add(rule("MISC_005", "Miscellaneous",
            "CREATE LOCAL TEMPORARY TABLE → CREATE TABLE #temp",
            "CREATE LOCAL TEMPORARY TABLE t", "CREATE TABLE #t",
            "\\bCREATE\\s+LOCAL\\s+TEMPORARY\\s+TABLE\\s+(\\w+)", F,
            "CREATE TABLE #$1 /*was: LOCAL TEMPORARY TABLE*/"));

        // @@IDENTITY → SCOPE_IDENTITY()
        r.add(rule("MISC_006", "Miscellaneous",
            "@@IDENTITY → SCOPE_IDENTITY()  (safer in SQL Server)",
            "SELECT @@IDENTITY", "SELECT SCOPE_IDENTITY()",
            "@@IDENTITY\\b", F, "SCOPE_IDENTITY()"));

        // DATEORDER (Sybase session option) — strip with comment
        r.add(rule("MISC_007", "Miscellaneous",
            "SET DATEORDER → removed (use SET DATEFORMAT in SQL Server if needed)",
            "SET TEMPORARY OPTION DATEORDER", "-- SET DATEFORMAT  -- review",
            "\\bSET\\s+TEMPORARY\\s+OPTION\\s+DATEORDER[^\n]*", F,
            "-- SET DATEFORMAT  -- review manually"));

        return r;
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  COMPLEX STRUCTURAL REWRITES
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * DECODE(expr, v1, r1, v2, r2, …, default) → CASE WHEN … END
     *
     * Handles nested parens and arbitrary number of WHEN/THEN pairs.
     */
    String rewriteDecode(String sql) {
        Pattern p = Pattern.compile("\\bDECODE\\s*\\(", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(sql);
        if (!m.find()) return sql;

        StringBuilder out  = new StringBuilder();
        int           last = 0;
        m.reset();

        while (m.find()) {
            out.append(sql, last, m.start());

            // Extract all top-level comma-separated args inside the outer parens
            int          openParen = m.end() - 1;   // position of '('
            List<String> args      = extractTopLevelArgs(sql, openParen);
            int          closeParen= findMatchingParen(sql, openParen);

            if (args == null || args.size() < 3) {
                // Can't parse — leave as-is
                out.append(sql, m.start(), closeParen + 1);
            } else {
                out.append(buildCaseWhen(args));
            }
            last = closeParen + 1;
        }

        out.append(sql, last, sql.length());
        return out.toString();
    }

    private String buildCaseWhen(List<String> args) {
        String        expr = args.get(0).trim();
        StringBuilder sb   = new StringBuilder("CASE");
        int           i    = 1;
        while (i + 1 < args.size()) {
            sb.append("\n           WHEN ").append(expr)
              .append(" = ").append(args.get(i).trim())
              .append(" THEN ").append(args.get(i + 1).trim());
            i += 2;
        }
        if (i < args.size()) {
            sb.append("\n           ELSE ").append(args.get(i).trim());
        }
        sb.append("\n       END");
        return sb.toString();
    }

    /**
     * LIST(col, 'sep')  →  STRING_AGG(col, 'sep')
     * LIST(col ORDER BY col, 'sep')  →  STRING_AGG(col, 'sep') WITHIN GROUP (ORDER BY col)
     */
    String rewriteListAggregate(String sql) {
        // Pattern: LIST( ... )
        Pattern p = Pattern.compile("\\bLIST\\s*\\(", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(sql);
        if (!m.find()) return sql;

        StringBuilder out  = new StringBuilder();
        int           last = 0;
        m.reset();

        while (m.find()) {
            out.append(sql, last, m.start());

            int          openParen  = m.end() - 1;
            int          closeParen = findMatchingParen(sql, openParen);
            String       inner      = sql.substring(openParen + 1, closeParen).trim();

            // Does it have ORDER BY inside?
            // Sybase: LIST(col ORDER BY col, 'sep')  — ORDER BY before the comma+separator
            Pattern obp = Pattern.compile(
                "^(.+?)\\s+ORDER\\s+BY\\s+(.+?),\\s*('[^']*'|\"[^\"]*\")\\s*$",
                Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
            Matcher obm = obp.matcher(inner);

            if (obm.matches()) {
                // Has ORDER BY
                String colExpr = obm.group(1).trim();
                String orderBy = obm.group(2).trim();
                String sep     = obm.group(3).trim();
                out.append("STRING_AGG(").append(colExpr).append(", ").append(sep)
                   .append(") WITHIN GROUP (ORDER BY ").append(orderBy).append(")");
            } else {
                // Simple LIST(col, 'sep')
                // Find the last top-level comma (separator is always the last arg)
                int lastComma = findLastTopLevelComma(inner);
                if (lastComma >= 0) {
                    String colExpr = inner.substring(0, lastComma).trim();
                    String sep     = inner.substring(lastComma + 1).trim();
                    out.append("STRING_AGG(").append(colExpr).append(", ").append(sep).append(")");
                } else {
                    // Fallback — can't parse; leave as-is with comment
                    out.append("STRING_AGG(").append(inner).append(") /*review LIST args*/");
                }
            }

            last = closeParen + 1;
        }

        out.append(sql, last, sql.length());
        return out.toString();
    }

    /**
     * TRIM(expr) → LTRIM(RTRIM(expr))
     *
     * Uses a paren balancer so nested parens are handled correctly.
     * Must NOT affect LTRIM / RTRIM (those are already correct).
     */
    String rewriteTrim(String sql) {
        // Match TRIM( but NOT LTRIM( and NOT RTRIM(
        Pattern p = Pattern.compile(
            "(?<![LlRr])\\bTRIM\\s*\\(", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(sql);
        if (!m.find()) return sql;

        StringBuilder out  = new StringBuilder();
        int           last = 0;
        m.reset();

        while (m.find()) {
            out.append(sql, last, m.start());

            int    openParen  = m.end() - 1;
            int    closeParen = findMatchingParen(sql, openParen);
            String inner      = sql.substring(openParen + 1, closeParen);

            out.append("LTRIM(RTRIM(").append(inner).append("))");
            last = closeParen + 1;
        }

        out.append(sql, last, sql.length());
        return out.toString();
    }

    /**
     * FETCH FIRST n ROWS ONLY  →  SELECT TOP n
     * LIMIT n                  →  SELECT TOP n
     *
     * Rewrites the SELECT keyword to include TOP n and strips the tail clause.
     */
    String rewriteTopN(String sql) {
        String result = sql;

        // FETCH FIRST n ROWS ONLY
        Pattern fp = Pattern.compile(
            "^(\\s*SELECT\\s+)(.*?)(\\s+FETCH\\s+FIRST\\s+(\\d+)\\s+ROWS\\s+ONLY\\s*)$",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
        Matcher fm = fp.matcher(result);
        if (fm.matches()) {
            return fm.group(1) + "TOP " + fm.group(4).trim() + " " + fm.group(2).trim();
        }

        // LIMIT n  (no OFFSET — simple case only)
        Pattern lp = Pattern.compile(
            "^(\\s*SELECT\\s+)(.*?)(\\s+LIMIT\\s+(\\d+)\\s*)$",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
        Matcher lm = lp.matcher(result);
        if (lm.matches()) {
            return lm.group(1) + "TOP " + lm.group(4).trim() + " " + lm.group(2).trim();
        }

        return result;
    }

    // ── Final cleanup pass ─────────────────────────────────────────────────────

    private String finalCleanup(String sql) {
        // Collapse multiple consecutive spaces (outside string literals — simplified)
        // and normalise line endings
        return sql
            .replaceAll("[ \\t]{2,}", " ")  // collapse inline multi-spaces
            .replaceAll("\\r\\n", "\n")
            .trim();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  PARSER UTILITIES
    // ══════════════════════════════════════════════════════════════════════════

    /** Find the closing ')' that matches the '(' at position {@code openPos}. */
    int findMatchingParen(String sql, int openPos) {
        int depth = 0;
        boolean inSingle = false;
        boolean inDouble = false;
        for (int i = openPos; i < sql.length(); i++) {
            char c = sql.charAt(i);
            if (c == '\'' && !inDouble) inSingle = !inSingle;
            else if (c == '"' && !inSingle) inDouble = !inDouble;
            else if (!inSingle && !inDouble) {
                if (c == '(') depth++;
                else if (c == ')') {
                    depth--;
                    if (depth == 0) return i;
                }
            }
        }
        return sql.length() - 1;
    }

    /** Extract top-level (depth-1) comma-separated arguments from inside parens. */
    List<String> extractTopLevelArgs(String sql, int openParenPos) {
        List<String> parts  = new ArrayList<>();
        StringBuilder cur   = new StringBuilder();
        int           depth = 0;
        boolean       inS   = false, inD = false;

        for (int i = openParenPos; i < sql.length(); i++) {
            char c = sql.charAt(i);
            if (c == '\'' && !inD) { inS = !inS; if (depth > 0) cur.append(c); }
            else if (c == '"' && !inS) { inD = !inD; if (depth > 0) cur.append(c); }
            else if (!inS && !inD) {
                if (c == '(') {
                    depth++;
                    if (depth > 1) cur.append(c);
                } else if (c == ')') {
                    depth--;
                    if (depth == 0) { parts.add(cur.toString()); return parts; }
                    else cur.append(c);
                } else if (c == ',' && depth == 1) {
                    parts.add(cur.toString());
                    cur = new StringBuilder();
                } else if (depth >= 1) {
                    cur.append(c);
                }
            } else {
                if (depth >= 1) cur.append(c);
            }
        }
        return parts;
    }

    /** Find the index of the last top-level comma in a string (no paren context). */
    private int findLastTopLevelComma(String s) {
        int  depth = 0, last = -1;
        boolean inS = false, inD = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if      (c == '\'' && !inD) inS = !inS;
            else if (c == '"'  && !inS) inD = !inD;
            else if (!inS && !inD) {
                if      (c == '(') depth++;
                else if (c == ')') depth--;
                else if (c == ',' && depth == 0) last = i;
            }
        }
        return last;
    }

    // ── Rule factory helper ────────────────────────────────────────────────────

    private ConversionRule rule(String id, String cat, String desc,
                                String sForm, String mForm,
                                String regex, int flags, String repl) {
        return new ConversionRule(id, cat, desc, sForm, mForm,
            Pattern.compile(regex, flags), repl);
    }
}
