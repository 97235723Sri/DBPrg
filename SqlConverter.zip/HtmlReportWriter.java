package com.converter.cli;

import com.converter.model.ConversionReport;
import com.converter.model.ConversionResult;
import com.converter.rule.ConversionRule;
import com.converter.rule.RuleMatch;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

/**
 * HtmlReportWriter
 * Generates a self-contained dark-theme HTML report for a ConversionReport.
 */
public class HtmlReportWriter {

    public Path write(ConversionReport report, Path outputDir,
                      List<ConversionRule> allRules) throws IOException {
        Files.createDirectories(outputDir);
        String ts   = report.getGeneratedAt().replace(":", "").replace(" ", "_");
        Path   out  = outputDir.resolve("conversion-report-" + ts + ".html");
        Files.writeString(out, buildHtml(report, allRules), StandardCharsets.UTF_8);
        return out;
    }

    // ── Build HTML ─────────────────────────────────────────────────────────────

    private String buildHtml(ConversionReport report, List<ConversionRule> allRules) {
        int changed   = report.getChangedCount();
        int unchanged = report.getUnchangedCount();
        int total     = report.getTotalQueries();

        StringBuilder sb = new StringBuilder();
        sb.append(head());
        sb.append("<body>\n");

        // ── Header ─────────────────────────────────────────────────────────────
        sb.append("""
            <header class="hdr">
              <div class="hdr-left">
                <span class="pill">SQL</span>
                <span class="title">Sybase IQ → MS SQL Converter</span>
              </div>
              <div class="hdr-right">
                Source: <code>%s</code> &nbsp;|&nbsp; Generated: %s
              </div>
            </header>
            """.formatted(esc(report.getSourceFile()), esc(report.getGeneratedAt())));

        // ── Summary cards ───────────────────────────────────────────────────────
        sb.append("""
            <section class="cards">
              <div class="card c-total"><div class="cv">%d</div><div class="cl">Total Queries</div></div>
              <div class="card c-conv"><div class="cv">%d</div><div class="cl">Converted</div></div>
              <div class="card c-same"><div class="cv">%d</div><div class="cl">No Change</div></div>
              <div class="card c-rules"><div class="cv">%d</div><div class="cl">Rule Types</div></div>
            </section>
            """.formatted(total, changed, unchanged, report.getRuleFrequency().size()));

        // ── Rule frequency bar ──────────────────────────────────────────────────
        sb.append("<section class=\"freq-section\"><h2>Most Applied Rules</h2><div class=\"freq-list\">\n");
        Map<String, Long> freq = report.getRuleFrequency();
        long maxFreq = freq.values().stream().mapToLong(v -> v).max().orElse(1);
        freq.entrySet().stream().limit(15).forEach(e -> {
            int pct = (int)(e.getValue() * 100 / maxFreq);
            sb.append("""
                <div class="freq-row">
                  <div class="freq-label">%s</div>
                  <div class="freq-bar-wrap">
                    <div class="freq-bar" style="width:%d%%"></div>
                  </div>
                  <div class="freq-count">%d</div>
                </div>
                """.formatted(esc(e.getKey()), pct, e.getValue()));
        });
        sb.append("</div></section>\n");

        // ── Filter + table ──────────────────────────────────────────────────────
        sb.append("""
            <section class="tbl-section">
              <div class="filter-row">
                <input id="sq" type="text" placeholder="🔍 Search label or SQL…" oninput="doFilter()">
                <select id="sf" onchange="doFilter()">
                  <option value="">All</option>
                  <option value="changed">Converted</option>
                  <option value="same">No Change</option>
                </select>
              </div>
              <table id="mt">
                <thead><tr>
                  <th>#</th><th>Label</th><th>Status</th>
                  <th>Rules Applied</th><th>Preview</th><th>Detail</th>
                </tr></thead>
                <tbody>
            """);

        for (ConversionResult r : report.getResults()) {
            String statusClass = r.isChanged() ? "badge-conv" : "badge-same";
            String statusText  = r.isChanged() ? "CONVERTED" : "NO CHANGE";
            String ruleList    = r.getAppliedRules().stream()
                .map(rm -> rm.description())
                .reduce((a, b) -> a + "; " + b).orElse("—");
            String preview     = esc(abbrev(r.getOriginalSql().replaceAll("\\s+", " "), 60));

            sb.append("<tr class=\"dr\" data-status=\"").append(r.isChanged() ? "changed" : "same").append("\"")
              .append(" data-label=\"").append(r.getQueryLabel()).append("\"")
              .append(" data-sql=\"").append(esc(abbrev(r.getOriginalSql(), 80))).append("\">\n")
              .append("<td>").append(r.getQueryIndex()).append("</td>\n")
              .append("<td><code>").append(r.getQueryLabel()).append("</code></td>\n")
              .append("<td><span class=\"badge ").append(statusClass).append("\">").append(statusText).append("</span></td>\n")
              .append("<td class=\"rule-count\">").append(r.getRuleCount()).append("</td>\n")
              .append("<td class=\"prev\">").append(preview).append("</td>\n")
              .append("<td><button class=\"btn\" onclick=\"toggle('p").append(r.getQueryIndex())
              .append("')\">▶ View</button></td>\n")
              .append("</tr>\n");
        }
        sb.append("</tbody></table></section>\n");

        // ── Detail panels ───────────────────────────────────────────────────────
        sb.append("<section class=\"panels\">\n");
        for (ConversionResult r : report.getResults()) {
            sb.append("<div id=\"p").append(r.getQueryIndex())
              .append("\" class=\"panel\" style=\"display:none\">\n");
            sb.append("<div class=\"panel-head\">\n")
              .append("<span class=\"panel-label\">").append(r.getQueryLabel()).append("</span>\n");
            if (r.isChanged()) {
                sb.append("<span class=\"badge badge-conv\">CONVERTED — ")
                  .append(r.getRuleCount()).append(" rule(s)</span>\n");
            } else {
                sb.append("<span class=\"badge badge-same\">NO CHANGE</span>\n");
            }
            sb.append("</div>\n");

            // Applied rules list
            if (!r.getAppliedRules().isEmpty()) {
                sb.append("<div class=\"rules-applied\"><strong>Rules applied:</strong><ul>\n");
                for (RuleMatch rm : r.getAppliedRules()) {
                    sb.append("<li>")
                      .append("<span class=\"rule-cat\">[").append(rm.category()).append("]</span> ")
                      .append(esc(rm.description()))
                      .append("</li>\n");
                }
                sb.append("</ul></div>\n");
            }

            // Side-by-side SQL
            sb.append("<div class=\"sql2col\">\n");
            sb.append("<div class=\"sql-box\">\n")
              .append("<div class=\"sql-hdr sybase-hdr\">🐋 Sybase IQ (Original)</div>\n")
              .append("<pre class=\"sql-pre\">").append(esc(r.getOriginalSql())).append("</pre>\n")
              .append("</div>\n");
            sb.append("<div class=\"sql-box\">\n")
              .append("<div class=\"sql-hdr mssql-hdr\">🟦 MS SQL Server (Converted)</div>\n")
              .append("<pre class=\"sql-pre converted\">").append(esc(r.getConvertedSql())).append("</pre>\n")
              .append("</div>\n");
            sb.append("</div>\n"); // sql2col

            sb.append("</div>\n"); // panel
        }
        sb.append("</section>\n");

        // ── Rule Reference Table ────────────────────────────────────────────────
        sb.append("<section class=\"ref-section\">\n");
        sb.append("<h2>📖 Full Rule Reference (").append(allRules.size()).append(" rules)</h2>\n");
        sb.append("<table class=\"ref-tbl\">\n");
        sb.append("<thead><tr><th>ID</th><th>Category</th><th>Description</th><th>Sybase IQ</th><th>MS SQL Server</th></tr></thead>\n<tbody>\n");
        String lastCat = "";
        for (ConversionRule rule : allRules) {
            if (!rule.category().equals(lastCat)) {
                sb.append("<tr class=\"cat-row\"><td colspan=\"5\">").append(esc(rule.category())).append("</td></tr>\n");
                lastCat = rule.category();
            }
            sb.append("<tr>\n")
              .append("<td><code>").append(rule.id()).append("</code></td>\n")
              .append("<td>").append(esc(rule.category())).append("</td>\n")
              .append("<td>").append(esc(rule.description())).append("</td>\n")
              .append("<td class=\"ex-sybase\"><code>").append(esc(rule.sybaseForm())).append("</code></td>\n")
              .append("<td class=\"ex-mssql\"><code>").append(esc(rule.mssqlForm())).append("</code></td>\n")
              .append("</tr>\n");
        }
        sb.append("</tbody></table></section>\n");

        sb.append("<footer>SQL Migration Converter &nbsp;|&nbsp; Sybase IQ → MS SQL &nbsp;|&nbsp; ").append(report.getGeneratedAt()).append("</footer>\n");
        sb.append(script());
        sb.append("</body></html>");
        return sb.toString();
    }

    // ── CSS + head ─────────────────────────────────────────────────────────────

    private String head() {
        return """
            <!DOCTYPE html><html lang="en"><head>
            <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
            <title>Sybase IQ → MS SQL Converter Report</title>
            <style>
            *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
            body{font-family:'Segoe UI',system-ui,sans-serif;background:#0d1117;color:#e6edf3;font-size:14px;line-height:1.6}
            code{font-family:'Cascadia Code','Fira Code',monospace;font-size:12px}
            pre{font-family:'Cascadia Code','Fira Code',monospace;font-size:12px;white-space:pre-wrap;word-break:break-word}

            .hdr{display:flex;align-items:center;justify-content:space-between;
              padding:16px 32px;background:#161b22;border-bottom:1px solid #30363d;
              position:sticky;top:0;z-index:50}
            .hdr-left{display:flex;align-items:center;gap:12px}
            .pill{background:linear-gradient(135deg,#58a6ff,#a371f7);
              color:#fff;padding:3px 10px;border-radius:4px;font-weight:700;font-size:13px}
            .title{font-size:18px;font-weight:700;color:#f0f6fc}
            .hdr-right{font-size:12px;color:#8b949e}

            .cards{display:flex;gap:16px;padding:28px 32px 0;flex-wrap:wrap}
            .card{flex:1;min-width:130px;background:#161b22;border:1px solid #30363d;
              border-radius:10px;padding:20px;text-align:center}
            .cv{font-size:36px;font-weight:800;letter-spacing:-1px}
            .cl{font-size:11px;color:#8b949e;text-transform:uppercase;letter-spacing:.8px;margin-top:4px}
            .c-total{border-color:#388bfd} .c-total .cv{color:#58a6ff}
            .c-conv {border-color:#3fb950} .c-conv  .cv{color:#56d364}
            .c-same {border-color:#8b949e} .c-same  .cv{color:#8b949e}
            .c-rules{border-color:#a371f7} .c-rules .cv{color:#bc8cff}

            .freq-section{padding:28px 32px 0}
            .freq-section h2,.ref-section h2{font-size:15px;color:#8b949e;
              font-weight:600;margin-bottom:14px;text-transform:uppercase;letter-spacing:.8px}
            .freq-list{display:flex;flex-direction:column;gap:6px;max-width:800px}
            .freq-row{display:flex;align-items:center;gap:10px}
            .freq-label{width:420px;font-size:12px;color:#c9d1d9;white-space:nowrap;
              overflow:hidden;text-overflow:ellipsis}
            .freq-bar-wrap{flex:1;background:#21262d;border-radius:4px;height:8px}
            .freq-bar{height:8px;border-radius:4px;
              background:linear-gradient(90deg,#58a6ff,#a371f7)}
            .freq-count{width:32px;text-align:right;font-size:12px;color:#8b949e}

            .tbl-section{padding:24px 32px}
            .filter-row{display:flex;gap:12px;margin-bottom:14px}
            .filter-row input,.filter-row select{
              background:#161b22;border:1px solid #30363d;color:#e6edf3;
              padding:8px 14px;border-radius:8px;outline:none;font-size:13px}
            .filter-row input{flex:1}
            .filter-row input:focus,.filter-row select:focus{border-color:#58a6ff}
            #mt{width:100%;border-collapse:collapse;background:#161b22;border-radius:10px;overflow:hidden}
            #mt th{background:#0d1117;color:#8b949e;font-size:11px;text-transform:uppercase;
              letter-spacing:.7px;padding:11px 14px;text-align:left}
            #mt td{padding:10px 14px;border-bottom:1px solid #21262d}
            #mt tbody tr:hover{background:#1c2128}
            #mt tbody tr:last-child td{border-bottom:none}
            .rule-count{color:#bc8cff;font-weight:600}
            .prev{color:#8b949e;font-size:12px;font-family:monospace}

            .badge{display:inline-block;padding:2px 10px;border-radius:20px;
              font-size:11px;font-weight:700;letter-spacing:.5px;text-transform:uppercase}
            .badge-conv{background:#1b3a1f;color:#56d364;border:1px solid #3fb950}
            .badge-same{background:#21262d;color:#8b949e;border:1px solid #30363d}

            .btn{background:#21262d;color:#e6edf3;border:1px solid #30363d;
              padding:4px 12px;border-radius:6px;cursor:pointer;font-size:12px}
            .btn:hover{background:#30363d}

            .panels{padding:0 32px 32px}
            .panel{background:#161b22;border:1px solid #30363d;border-radius:10px;
              padding:22px;margin-bottom:16px}
            .panel-head{display:flex;align-items:center;gap:12px;margin-bottom:16px}
            .panel-label{font-size:15px;font-weight:700;color:#f0f6fc}
            .rules-applied{background:#0d1117;border-left:3px solid #a371f7;
              padding:10px 14px;border-radius:0 6px 6px 0;margin-bottom:14px;font-size:12px}
            .rules-applied ul{margin:6px 0 0 16px}
            .rules-applied li{margin-bottom:3px;color:#c9d1d9}
            .rule-cat{color:#58a6ff;font-weight:600}
            .sql2col{display:grid;grid-template-columns:1fr 1fr;gap:14px}
            @media(max-width:800px){.sql2col{grid-template-columns:1fr}}
            .sql-box{background:#0d1117;border-radius:8px;overflow:hidden}
            .sql-hdr{padding:7px 14px;font-size:12px;font-weight:600;
              border-bottom:1px solid #21262d}
            .sybase-hdr{color:#58a6ff;background:#0d1523}
            .mssql-hdr{color:#56d364;background:#0d1a10}
            .sql-pre{padding:14px;max-height:360px;overflow-y:auto;color:#c9d1d9}
            .sql-pre.converted{color:#79c0ff}

            .ref-section{padding:24px 32px 40px}
            .ref-tbl{width:100%;border-collapse:collapse;background:#161b22;
              border-radius:10px;overflow:hidden;font-size:12px}
            .ref-tbl th{background:#0d1117;color:#8b949e;padding:9px 12px;text-align:left;
              font-size:11px;text-transform:uppercase;letter-spacing:.6px}
            .ref-tbl td{padding:8px 12px;border-bottom:1px solid #21262d}
            .ref-tbl tbody tr:hover{background:#1c2128}
            .cat-row td{background:#0d1117 !important;color:#a371f7;font-weight:700;
              padding:6px 12px;font-size:11px;text-transform:uppercase;letter-spacing:1px}
            .ex-sybase code{color:#f85149}
            .ex-mssql  code{color:#56d364}

            footer{text-align:center;padding:16px 32px;
              border-top:1px solid #21262d;color:#484f58;font-size:12px}
            ::-webkit-scrollbar{width:5px;height:5px}
            ::-webkit-scrollbar-track{background:#0d1117}
            ::-webkit-scrollbar-thumb{background:#30363d;border-radius:3px}
            </style>
            </head>
            """;
    }

    private String script() {
        return """
            <script>
            function toggle(id){
              var el=document.getElementById(id);
              if(!el)return;
              var v=el.style.display!=='none';
              el.style.display=v?'none':'block';
              if(!v)el.scrollIntoView({behavior:'smooth',block:'start'});
            }
            function doFilter(){
              var s=document.getElementById('sq').value.toLowerCase();
              var f=document.getElementById('sf').value;
              document.querySelectorAll('.dr').forEach(function(r){
                var l=(r.dataset.label||'').toLowerCase();
                var q=(r.dataset.sql||'').toLowerCase();
                var st=(r.dataset.status||'');
                var ms=!s||l.includes(s)||q.includes(s);
                var mf=!f||st===f;
                r.style.display=(ms&&mf)?'':'none';
              });
            }
            </script>
            """;
    }

    // ── Utilities ──────────────────────────────────────────────────────────────

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("&","&amp;").replace("<","&lt;")
                .replace(">","&gt;").replace("\"","&quot;");
    }

    private String abbrev(String s, int max) {
        if (s == null) return "";
        return s.length() > max ? s.substring(0, max) + "…" : s;
    }
}
