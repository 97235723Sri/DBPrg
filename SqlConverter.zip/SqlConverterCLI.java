package com.converter.cli;

import com.converter.engine.SqlFileProcessor;
import com.converter.engine.SybaseToMsSqlConverter;
import com.converter.model.ConversionReport;
import com.converter.model.ConversionResult;
import com.converter.rule.RuleMatch;

import java.io.*;
import java.nio.file.*;
import java.util.List;
import java.util.Scanner;

/**
 * SqlConverterCLI
 * ──────────────────────────────────────────────────────────────────────────────
 * Main entry point for the Sybase IQ → MS SQL converter.
 *
 * Usage modes:
 *
 *   1. File mode:
 *        java -jar converter.jar input.sql [output.sql] [--html]
 *
 *   2. Interactive (REPL) mode:
 *        java -jar converter.jar
 *        > paste SQL here, type GO on a new line to convert
 *
 *   3. Inline single-query mode:
 *        java -jar converter.jar --query "SELECT NVL(a,0) FROM t"
 *
 *   4. Print rules table:
 *        java -jar converter.jar --rules
 */
public class SqlConverterCLI {

    private static final String BANNER = """
        ╔══════════════════════════════════════════════════════════════╗
        ║      Sybase IQ  →  MS SQL Server  SQL Converter             ║
        ║      50+ conversion rules  |  Batch + Interactive modes     ║
        ╚══════════════════════════════════════════════════════════════╝
        """;

    public static void main(String[] args) throws Exception {
        System.out.println(BANNER);

        SybaseToMsSqlConverter converter  = new SybaseToMsSqlConverter();
        SqlFileProcessor       processor  = new SqlFileProcessor(converter);
        HtmlReportWriter       htmlWriter = new HtmlReportWriter();

        // ── Mode: print all rules ─────────────────────────────────────────────
        if (hasFlag(args, "--rules")) {
            printRulesTable(converter);
            return;
        }

        // ── Mode: single inline query ─────────────────────────────────────────
        String inlineQuery = flagValue(args, "--query");
        if (inlineQuery != null) {
            ConversionResult r = converter.convert(1, "Q001", inlineQuery);
            printSingleResult(r);
            return;
        }

        // ── Mode: file processing ─────────────────────────────────────────────
        String inputFile = nonFlagArg(args, 0);
        if (inputFile != null) {
            Path inputPath  = Paths.get(inputFile);
            if (!Files.exists(inputPath)) {
                System.err.println("ERROR: File not found — " + inputPath);
                System.exit(1);
            }

            String outputFile = nonFlagArg(args, 1);
            Path   outputPath = outputFile != null
                ? Paths.get(outputFile)
                : inputPath.resolveSibling(
                    stripExt(inputPath.getFileName().toString()) + "_mssql.sql");

            System.out.println("  Input : " + inputPath.toAbsolutePath());
            System.out.println("  Output: " + outputPath.toAbsolutePath());
            System.out.println();

            ConversionReport report = processor.processFile(inputPath, outputPath);
            printSummary(report);

            // Optional HTML report
            if (hasFlag(args, "--html")) {
                Path htmlDir  = outputPath.getParent() != null ? outputPath.getParent() : Paths.get(".");
                Path htmlPath = htmlWriter.write(report, htmlDir, converter.getAllRules());
                System.out.println("\n  HTML report → " + htmlPath.toAbsolutePath());
            }

            // Print detail for changed queries
            if (hasFlag(args, "--detail") || hasFlag(args, "-v")) {
                report.getResults().stream()
                    .filter(ConversionResult::isChanged)
                    .forEach(SqlConverterCLI::printSingleResult);
            }

            return;
        }

        // ── Mode: interactive REPL ────────────────────────────────────────────
        System.out.println("  Interactive mode. Paste Sybase IQ SQL and type GO on a new line.");
        System.out.println("  Type EXIT to quit.  Type RULES to list all rules.\n");

        Scanner  sc   = new Scanner(System.in);
        int      idx  = 1;
        StringBuilder buf = new StringBuilder();

        while (true) {
            System.out.print("> ");
            String line = sc.hasNextLine() ? sc.nextLine() : "EXIT";

            if (line.equalsIgnoreCase("EXIT") || line.equalsIgnoreCase("QUIT")) break;

            if (line.equalsIgnoreCase("RULES")) {
                printRulesTable(converter);
                buf.setLength(0);
                continue;
            }

            if (line.equalsIgnoreCase("GO")) {
                String sql = buf.toString().trim();
                if (!sql.isBlank()) {
                    ConversionResult r = converter.convert(idx++, String.format("Q%03d", idx - 1), sql);
                    printSingleResult(r);
                }
                buf.setLength(0);
            } else {
                buf.append(line).append("\n");
            }
        }

        System.out.println("\n  Bye!");
    }

    // ── Print helpers ──────────────────────────────────────────────────────────

    private static void printSingleResult(ConversionResult r) {
        System.out.println();
        System.out.println("┌─ " + r.getQueryLabel() + " " +
            (r.isChanged() ? "[CONVERTED — " + r.getRuleCount() + " rule(s)]" : "[NO CHANGE]"));
        System.out.println("│");

        if (!r.getAppliedRules().isEmpty()) {
            System.out.println("│  Rules applied:");
            for (RuleMatch rm : r.getAppliedRules()) {
                System.out.println("│    ✔  [" + rm.category() + "] " + rm.description());
            }
            System.out.println("│");
        }

        System.out.println("│  ── Original (Sybase IQ) ──────────────────────────────────");
        printIndented(r.getOriginalSql(), "│  ");
        System.out.println("│");
        System.out.println("│  ── Converted (MS SQL Server) ─────────────────────────────");
        printIndented(r.getConvertedSql(), "│  ");
        System.out.println("└────────────────────────────────────────────────────────────\n");
    }

    private static void printIndented(String sql, String prefix) {
        for (String line : sql.split("\n")) {
            System.out.println(prefix + line);
        }
    }

    private static void printSummary(ConversionReport report) {
        int total     = report.getTotalQueries();
        int converted = report.getChangedCount();
        int unchanged = report.getUnchangedCount();

        System.out.println();
        System.out.println("  ╔══════════════════════════════════════╗");
        System.out.printf ("  ║  Total queries  : %-18d║%n", total);
        System.out.printf ("  ║  Converted      : %-18d║%n", converted);
        System.out.printf ("  ║  No change      : %-18d║%n", unchanged);
        System.out.println("  ╚══════════════════════════════════════╝");

        if (!report.getRuleFrequency().isEmpty()) {
            System.out.println("\n  Top conversion rules fired:");
            report.getRuleFrequency().entrySet().stream().limit(10).forEach(e ->
                System.out.printf("    %3dx  %s%n", e.getValue(), e.getKey()));
        }
        System.out.println();
    }

    private static void printRulesTable(SybaseToMsSqlConverter converter) {
        System.out.println("\n  All conversion rules:\n");
        String lastCat = "";
        for (var rule : converter.getAllRules()) {
            if (!rule.category().equals(lastCat)) {
                System.out.println("  ── " + rule.category() + " " + "─".repeat(50 - rule.category().length()));
                lastCat = rule.category();
            }
            System.out.printf("  %-10s  %-60s%n", rule.id(), rule.description());
            System.out.printf("  %-10s  Sybase: %-30s  →  %s%n",
                "", rule.sybaseForm(), rule.mssqlForm());
            System.out.println();
        }
    }

    // ── Arg utilities ──────────────────────────────────────────────────────────

    private static boolean hasFlag(String[] args, String flag) {
        for (String a : args) if (a.equalsIgnoreCase(flag)) return true;
        return false;
    }

    private static String flagValue(String[] args, String flag) {
        for (int i = 0; i < args.length - 1; i++) {
            if (args[i].equalsIgnoreCase(flag)) return args[i + 1];
        }
        return null;
    }

    /** Return the nth non-flag argument (0-based). */
    private static String nonFlagArg(String[] args, int n) {
        int count = 0;
        for (String a : args) {
            if (!a.startsWith("--") && !a.startsWith("-")) {
                if (count++ == n) return a;
            }
        }
        return null;
    }

    private static String stripExt(String filename) {
        int dot = filename.lastIndexOf('.');
        return dot > 0 ? filename.substring(0, dot) : filename;
    }
}
