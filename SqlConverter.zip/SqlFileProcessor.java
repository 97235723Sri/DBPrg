package com.converter.engine;

import com.converter.model.ConversionReport;
import com.converter.model.ConversionResult;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * SqlFileProcessor
 * ──────────────────────────────────────────────────────────────────────────────
 * Reads a .sql file containing multiple Sybase IQ queries (semicolon-delimited),
 * converts every query, and returns a ConversionReport.
 *
 * Also writes the converted queries to an output .sql file.
 */
public class SqlFileProcessor {

    private final SybaseToMsSqlConverter converter;

    public SqlFileProcessor() {
        this.converter = new SybaseToMsSqlConverter();
    }

    public SqlFileProcessor(SybaseToMsSqlConverter converter) {
        this.converter = converter;
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Process a file
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Read {@code inputPath}, convert every query, write converted SQL to
     * {@code outputPath}, and return the full ConversionReport.
     */
    public ConversionReport processFile(Path inputPath, Path outputPath) throws IOException {
        String raw = Files.readString(inputPath, StandardCharsets.UTF_8);

        List<String> queries = splitQueries(raw);
        System.out.printf("  Loaded %d queries from %s%n", queries.size(), inputPath.getFileName());

        List<ConversionResult> results = new ArrayList<>();
        for (int i = 0; i < queries.size(); i++) {
            String label  = String.format("Q%03d", i + 1);
            ConversionResult result = converter.convert(i + 1, label, queries.get(i));
            results.add(result);
        }

        // Write converted SQL output
        if (outputPath != null) {
            writeConvertedFile(results, outputPath, inputPath.getFileName().toString());
            System.out.printf("  Converted SQL written to %s%n", outputPath);
        }

        String ts = LocalDateTime.now()
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        return new ConversionReport(results, ts, inputPath.getFileName().toString());
    }

    /**
     * Convert a single raw SQL string (may contain multiple queries).
     */
    public ConversionReport processString(String rawSql, String sourceName) {
        List<String> queries = splitQueries(rawSql);
        List<ConversionResult> results = new ArrayList<>();
        for (int i = 0; i < queries.size(); i++) {
            String label = String.format("Q%03d", i + 1);
            results.add(converter.convert(i + 1, label, queries.get(i)));
        }
        String ts = LocalDateTime.now()
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        return new ConversionReport(results, ts, sourceName);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Output writers
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Write a clean converted SQL file — one query per block with header comments.
     */
    private void writeConvertedFile(List<ConversionResult> results,
                                    Path outPath, String sourceName) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("-- ============================================================\n");
        sb.append("-- Converted from Sybase IQ → MS SQL Server (T-SQL)\n");
        sb.append("-- Source : ").append(sourceName).append("\n");
        sb.append("-- Generated: ").append(
            LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))).append("\n");
        sb.append("-- Queries : ").append(results.size()).append("\n");
        sb.append("-- Changed : ").append(
            results.stream().filter(ConversionResult::isChanged).count()).append("\n");
        sb.append("-- ============================================================\n\n");

        for (ConversionResult r : results) {
            sb.append("-- ──────────────────────────────────────────────────────────\n");
            sb.append("-- ").append(r.getQueryLabel());
            if (r.isChanged()) {
                sb.append("  [CONVERTED — ").append(r.getRuleCount()).append(" rule(s)]");
            } else {
                sb.append("  [NO CHANGE]");
            }
            sb.append("\n");
            if (!r.getAppliedRules().isEmpty()) {
                r.getAppliedRules().forEach(rm ->
                    sb.append("--   • ").append(rm.description()).append("\n"));
            }
            sb.append("-- ──────────────────────────────────────────────────────────\n");
            sb.append(r.getConvertedSql().trim()).append(";\n\n");
        }

        Files.writeString(outPath, sb.toString(), StandardCharsets.UTF_8);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Query splitter
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Split a raw SQL string into individual query strings.
     *
     * Rules:
     *  • Statement delimiter is ';'
     *  • Block comments  /* … *​/ are stripped
     *  • Line comments   -- …    are stripped
     *  • Blank results are discarded
     */
    public List<String> splitQueries(String raw) {
        if (raw == null || raw.isBlank()) return List.of();

        // 1. Remove block comments
        String noBlock = raw.replaceAll("(?s)/\\*.*?\\*/", " ");

        // 2. Split on semicolons
        String[] parts = noBlock.split(";");

        List<String> queries = new ArrayList<>();
        for (String part : parts) {
            // 3. Remove line comments
            String cleaned = Arrays.stream(part.split("\n"))
                .filter(line -> !line.stripLeading().startsWith("--"))
                .collect(Collectors.joining("\n"))
                .trim();

            if (!cleaned.isBlank()) {
                queries.add(cleaned);
            }
        }
        return queries;
    }
}
