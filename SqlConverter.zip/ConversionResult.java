package com.converter.model;

import com.converter.rule.RuleMatch;

import java.util.List;

/**
 * ConversionResult — everything produced when one Sybase SQL string is converted.
 */
public class ConversionResult {

    private final String          originalSql;
    private final String          convertedSql;
    private final List<RuleMatch> appliedRules;
    private final boolean         changed;
    private final int             queryIndex;     // 1-based, optional
    private final String          queryLabel;     // e.g. "Q001"

    public ConversionResult(int queryIndex, String queryLabel,
                            String originalSql, String convertedSql,
                            List<RuleMatch> appliedRules) {
        this.queryIndex   = queryIndex;
        this.queryLabel   = queryLabel;
        this.originalSql  = originalSql;
        this.convertedSql = convertedSql;
        this.appliedRules = appliedRules;
        this.changed      = !originalSql.equals(convertedSql);
    }

    public String          getOriginalSql()  { return originalSql;  }
    public String          getConvertedSql() { return convertedSql; }
    public List<RuleMatch> getAppliedRules() { return appliedRules; }
    public boolean         isChanged()       { return changed;       }
    public int             getQueryIndex()   { return queryIndex;    }
    public String          getQueryLabel()   { return queryLabel;    }
    public int             getRuleCount()    { return appliedRules.size(); }
}
