package com.converter.rule;

/**
 * RuleMatch — one record of a rule that was applied during conversion.
 *
 * @param ruleId      Rule ID
 * @param category    Rule category
 * @param description Human-readable description of what changed
 * @param sybaseForm  What Sybase syntax looked like
 * @param mssqlForm   What it was converted to
 */
public record RuleMatch(
        String ruleId,
        String category,
        String description,
        String sybaseForm,
        String mssqlForm
) {}
