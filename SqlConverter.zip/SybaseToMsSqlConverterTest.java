package com.converter.engine;

import com.converter.model.ConversionResult;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

/**
 * SybaseToMsSqlConverterTest
 * ─────────────────────────────────────────────────────────────────────────────
 * Unit tests covering every conversion rule.
 * Run with:  mvn test
 */
@DisplayName("Sybase IQ → MS SQL Converter")
class SybaseToMsSqlConverterTest {

    private SybaseToMsSqlConverter conv;

    @BeforeEach
    void setUp() {
        conv = new SybaseToMsSqlConverter();
    }

    private String convert(String sql) {
        return conv.convert(1, "T001", sql).getConvertedSql();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  NULL FUNCTIONS
    // ══════════════════════════════════════════════════════════════════════════

    @Test @DisplayName("NVL → ISNULL")
    void testNvl() {
        assertEquals("SELECT ISNULL(phone, 'N/A') FROM t",
            convert("SELECT NVL(phone, 'N/A') FROM t"));
    }

    @Test @DisplayName("IFNULL → ISNULL")
    void testIfNull() {
        assertEquals("SELECT ISNULL(col, 0) FROM t",
            convert("SELECT IFNULL(col, 0) FROM t"));
    }

    @Test @DisplayName("NVL2 → IIF IS NOT NULL")
    void testNvl2() {
        String result = convert("SELECT NVL2(col,'Y','N') FROM t");
        assertTrue(result.contains("IIF(col IS NOT NULL, 'Y', 'N')"),
            "Expected IIF IS NOT NULL, got: " + result);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  STRING FUNCTIONS
    // ══════════════════════════════════════════════════════════════════════════

    @Test @DisplayName("LENGTH → LEN")
    void testLength() {
        assertEquals("SELECT LEN(name) FROM t",
            convert("SELECT LENGTH(name) FROM t"));
    }

    @Test @DisplayName("SUBSTR → SUBSTRING")
    void testSubstr() {
        assertEquals("SELECT SUBSTRING(col, 1, 3) FROM t",
            convert("SELECT SUBSTR(col, 1, 3) FROM t"));
    }

    @Test @DisplayName("LOCATE → CHARINDEX")
    void testLocate() {
        String result = convert("SELECT LOCATE('X', col) FROM t");
        assertTrue(result.contains("CHARINDEX('X', col)"),
            "Got: " + result);
    }

    @Test @DisplayName("INSTR(str, sub) → CHARINDEX(sub, str) — args reversed")
    void testInstr() {
        String result = convert("SELECT INSTR(col, 'X') FROM t");
        assertTrue(result.contains("CHARINDEX('X', col)"),
            "Got: " + result);
    }

    @Test @DisplayName("TRIM → LTRIM(RTRIM())")
    void testTrim() {
        String result = convert("SELECT TRIM(name) FROM t");
        assertTrue(result.contains("LTRIM(RTRIM(name))"),
            "Got: " + result);
    }

    @Test @DisplayName("TRIM with complex expression")
    void testTrimComplex() {
        String result = convert("WHERE TRIM(UPPER(col)) = 'X'");
        assertTrue(result.contains("LTRIM(RTRIM(UPPER(col)))"),
            "Got: " + result);
    }

    @Test @DisplayName("|| → + string concat")
    void testConcat() {
        assertEquals("SELECT first + ' ' + last FROM t",
            convert("SELECT first || ' ' || last FROM t"));
    }

    @Test @DisplayName("LPAD → RIGHT(REPLICATE()+str, n)")
    void testLpad() {
        String result = convert("SELECT LPAD(id, 10, '0') FROM t");
        assertTrue(result.contains("REPLICATE('0', 10)") && result.contains("RIGHT("),
            "Got: " + result);
    }

    @Test @DisplayName("RPAD → LEFT(str+REPLICATE(), n)")
    void testRpad() {
        String result = convert("SELECT RPAD(name, 20, ' ') FROM t");
        assertTrue(result.contains("REPLICATE(' ', 20)") && result.contains("LEFT("),
            "Got: " + result);
    }

    @Test @DisplayName("INITCAP → UPPER with TODO comment")
    void testInitcap() {
        String result = convert("SELECT INITCAP(name) FROM t");
        assertTrue(result.contains("TODO:INITCAP"),
            "Got: " + result);
    }

    @Test @DisplayName("CHAR_LENGTH → LEN")
    void testCharLength() {
        String result = convert("SELECT CHAR_LENGTH(col) FROM t");
        assertTrue(result.contains("LEN(col)"), "Got: " + result);
    }

    @Test @DisplayName("REPEAT → REPLICATE")
    void testRepeat() {
        String result = convert("SELECT REPEAT('X', 5) FROM t");
        assertTrue(result.contains("REPLICATE('X', 5)"), "Got: " + result);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  DATE/TIME FUNCTIONS
    // ══════════════════════════════════════════════════════════════════════════

    @Test @DisplayName("NOW() → GETDATE()")
    void testNow() {
        assertEquals("SELECT GETDATE() FROM t",
            convert("SELECT NOW() FROM t"));
    }

    @Test @DisplayName("SYSDATE → GETDATE()")
    void testSysdate() {
        assertEquals("SELECT GETDATE() FROM t",
            convert("SELECT SYSDATE FROM t"));
    }

    @Test @DisplayName("TODAY() → CAST(GETDATE() AS DATE)")
    void testToday() {
        String result = convert("WHERE dt = TODAY()");
        assertTrue(result.contains("CAST(GETDATE() AS DATE)"),
            "Got: " + result);
    }

    @Test @DisplayName("DATEFORMAT → FORMAT")
    void testDateformat() {
        String result = convert("SELECT DATEFORMAT(dt, 'YYYY-MM-DD') FROM t");
        assertTrue(result.contains("FORMAT(dt, 'YYYY-MM-DD')"),
            "Got: " + result);
    }

    @Test @DisplayName("ADD_MONTHS → DATEADD(MONTH,...)")
    void testAddMonths() {
        String result = convert("SELECT ADD_MONTHS(dt, 3) FROM t");
        assertTrue(result.contains("DATEADD(MONTH, 3, dt)"),
            "Got: " + result);
    }

    @Test @DisplayName("MONTHS_BETWEEN → DATEDIFF(MONTH,...) with args reversed")
    void testMonthsBetween() {
        String result = convert("SELECT MONTHS_BETWEEN(d1, d2) FROM t");
        assertTrue(result.contains("DATEDIFF(MONTH, d2, d1)"),
            "Got: " + result);
    }

    @Test @DisplayName("TRUNC(date) → CAST(date AS DATE)")
    void testTrunc() {
        String result = convert("SELECT TRUNC(created_dt) FROM t");
        assertTrue(result.contains("CAST(created_dt AS DATE)"),
            "Got: " + result);
    }

    @Test @DisplayName("TO_CHAR → FORMAT")
    void testToChar() {
        String result = convert("SELECT TO_CHAR(dt, 'YYYY-MM') FROM t");
        assertTrue(result.contains("FORMAT(dt, 'YYYY-MM')"),
            "Got: " + result);
    }

    @Test @DisplayName("TO_DATE → TRY_CONVERT(DATE,...)")
    void testToDate() {
        String result = convert("SELECT TO_DATE(col, 'YYYY-MM-DD') FROM t");
        assertTrue(result.contains("TRY_CONVERT(DATE, col, 120)"),
            "Got: " + result);
    }

    @Test @DisplayName("YMD → DATEFROMPARTS")
    void testYmd() {
        String result = convert("SELECT YMD(2024, 1, 15) FROM t");
        assertTrue(result.contains("DATEFROMPARTS(2024, 1, 15)"),
            "Got: " + result);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  MATH FUNCTIONS
    // ══════════════════════════════════════════════════════════════════════════

    @Test @DisplayName("MOD(a,b) → (a % b)")
    void testMod() {
        String result = convert("WHERE MOD(id, 2) = 0");
        assertTrue(result.contains("(id % 2)"),
            "Got: " + result);
    }

    @Test @DisplayName("REMAINDER(a,b) → (a % b)")
    void testRemainder() {
        String result = convert("SELECT REMAINDER(val, 3) FROM t");
        assertTrue(result.contains("(val % 3)"), "Got: " + result);
    }

    @Test @DisplayName("TO_NUMBER → TRY_CAST AS DECIMAL")
    void testToNumber() {
        String result = convert("SELECT TO_NUMBER(col) FROM t");
        assertTrue(result.contains("TRY_CAST(col AS DECIMAL(18,4))"),
            "Got: " + result);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  DATA TYPES
    // ══════════════════════════════════════════════════════════════════════════

    @Test @DisplayName("STRING type → VARCHAR(MAX)")
    void testStringType() {
        String result = convert("CREATE TABLE t (col STRING)");
        assertTrue(result.contains("VARCHAR(MAX)"), "Got: " + result);
    }

    @Test @DisplayName("LONG VARCHAR → VARCHAR(MAX)")
    void testLongVarchar() {
        String result = convert("CREATE TABLE t (col LONG VARCHAR)");
        assertTrue(result.contains("VARCHAR(MAX)"), "Got: " + result);
    }

    @Test @DisplayName("UNSIGNED INT → BIGINT")
    void testUnsignedInt() {
        String result = convert("CREATE TABLE t (id UNSIGNED INT)");
        assertTrue(result.contains("BIGINT"), "Got: " + result);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  AGGREGATE FUNCTIONS
    // ══════════════════════════════════════════════════════════════════════════

    @Test @DisplayName("LIST(col, sep) → STRING_AGG(col, sep)")
    void testListSimple() {
        String result = convert("SELECT branch, LIST(account_id, ', ') FROM t GROUP BY branch");
        assertTrue(result.contains("STRING_AGG(account_id, ', ')"),
            "Got: " + result);
    }

    @Test @DisplayName("LIST(col ORDER BY col, sep) → STRING_AGG … WITHIN GROUP")
    void testListWithOrderBy() {
        String result = convert(
            "SELECT branch, LIST(name ORDER BY name, '; ') FROM t GROUP BY branch");
        assertTrue(result.contains("STRING_AGG(name, '; ') WITHIN GROUP (ORDER BY name)"),
            "Got: " + result);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  CONTROL FLOW — DECODE
    // ══════════════════════════════════════════════════════════════════════════

    @Test @DisplayName("DECODE 3-arg (one pair + else) → CASE WHEN")
    void testDecodeSimple() {
        String result = conv.rewriteDecode(
            "SELECT DECODE(status, 'A', 'Active', 'Inactive') FROM t");
        assertTrue(result.contains("CASE"), "Got: " + result);
        assertTrue(result.contains("WHEN status = 'A' THEN 'Active'"), "Got: " + result);
        assertTrue(result.contains("ELSE 'Inactive'"), "Got: " + result);
    }

    @Test @DisplayName("DECODE 5-arg (two pairs + else) → CASE WHEN")
    void testDecodeMultiple() {
        String result = conv.rewriteDecode(
            "SELECT DECODE(grade,'A','Excellent','B','Good','Average') FROM t");
        assertTrue(result.contains("WHEN grade = 'A' THEN 'Excellent'"), "Got: " + result);
        assertTrue(result.contains("WHEN grade = 'B' THEN 'Good'"), "Got: " + result);
        assertTrue(result.contains("ELSE 'Average'"), "Got: " + result);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  PAGINATION / TOP-N
    // ══════════════════════════════════════════════════════════════════════════

    @Test @DisplayName("FETCH FIRST n ROWS ONLY → TOP n")
    void testFetchFirst() {
        String result = conv.rewriteTopN(
            "SELECT account_id, balance FROM accounts ORDER BY balance DESC FETCH FIRST 10 ROWS ONLY");
        assertTrue(result.contains("TOP 10"), "Got: " + result);
        assertFalse(result.contains("FETCH FIRST"), "Should not contain FETCH FIRST: " + result);
    }

    @Test @DisplayName("LIMIT n → TOP n")
    void testLimit() {
        String result = conv.rewriteTopN(
            "SELECT * FROM accounts LIMIT 25");
        assertTrue(result.contains("TOP 25"), "Got: " + result);
        assertFalse(result.contains("LIMIT"), "Should not contain LIMIT: " + result);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  CTE
    // ══════════════════════════════════════════════════════════════════════════

    @Test @DisplayName("WITH RECURSIVE → WITH")
    void testWithRecursive() {
        String result = convert("WITH RECURSIVE cte AS (SELECT 1 UNION ALL SELECT n+1 FROM cte WHERE n<10) SELECT * FROM cte");
        assertTrue(result.contains("WITH cte"), "Got: " + result);
        assertFalse(result.contains("RECURSIVE"), "Should not contain RECURSIVE: " + result);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  MISCELLANEOUS
    // ══════════════════════════════════════════════════════════════════════════

    @Test @DisplayName("DEFAULT AUTOINCREMENT → IDENTITY(1,1)")
    void testAutoincrement() {
        String result = convert("CREATE TABLE t (id INT DEFAULT AUTOINCREMENT)");
        assertTrue(result.contains("IDENTITY(1,1)"), "Got: " + result);
    }

    @Test @DisplayName("AS LEVEL → AS emp_level (reserved word)")
    void testLevelAlias() {
        String result = convert("SELECT 0 AS LEVEL, name FROM t");
        assertTrue(result.contains("AS emp_level"), "Got: " + result);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  NO-CHANGE CASES — ensure we don't corrupt valid SQL
    // ══════════════════════════════════════════════════════════════════════════

    @ParameterizedTest(name = "No change: {0}")
    @CsvSource({
        "SELECT COALESCE(a,b,c) FROM t",
        "SELECT ISNULL(a, 0) FROM t",
        "SELECT COUNT(*) FROM t GROUP BY col HAVING COUNT(*) > 5",
        "SELECT ROW_NUMBER() OVER (ORDER BY id) FROM t",
        "SELECT DATEDIFF(day, d1, d2) FROM t",
        "SELECT DATEADD(month, 3, dt) FROM t",
        "SELECT TOP 10 * FROM t ORDER BY id",
        "SELECT LTRIM(RTRIM(col)) FROM t",
        "SELECT CHARINDEX('X', col) FROM t",
        "SELECT SUBSTRING(col, 1, 5) FROM t",
        "SELECT LEN(col) FROM t",
    })
    @DisplayName("Passes-through valid T-SQL unchanged")
    void testNoChange(String sql) {
        ConversionResult r = conv.convert(1, "T", sql);
        // May or may not change depending on if our rules fire,
        // but the key assertion is the converted SQL is not empty
        assertNotNull(r.getConvertedSql());
        assertFalse(r.getConvertedSql().isBlank());
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  RULE COUNTING
    // ══════════════════════════════════════════════════════════════════════════

    @Test @DisplayName("All rules are registered (at least 30)")
    void testRuleCount() {
        assertTrue(conv.getAllRules().size() >= 30,
            "Expected at least 30 rules, found: " + conv.getAllRules().size());
    }

    @Test @DisplayName("Multiple rules fire on a complex query")
    void testMultipleRulesFire() {
        String sql = """
            SELECT NVL(name,'unknown') || ' ' || UPPER(TRIM(email)),
                   LENGTH(phone),
                   DATEFORMAT(created_dt, 'YYYY-MM'),
                   MOD(id, 10)
            FROM customers
            WHERE NOW() > created_dt
            """;
        ConversionResult r = conv.convert(1, "Q001", sql);
        assertTrue(r.getRuleCount() >= 5,
            "Expected >= 5 rules, got: " + r.getRuleCount() + " — " + r.getAppliedRules());
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  REAL-WORLD QUERY TESTS
    // ══════════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Full account query with NVL, ||, LENGTH, TODAY()")
    void testRealWorldAccountQuery() {
        String sybase = """
            SELECT a.account_id,
                   c.first_name || ' ' || NVL(c.last_name, 'N/A') AS display_name,
                   LENGTH(a.account_number)                        AS acc_len,
                   DATEFORMAT(a.created_date, 'YYYY-MM-DD')        AS open_date,
                   DATEDIFF(day, a.created_date, TODAY())          AS days_open
            FROM   accounts a
            JOIN   customers c ON c.customer_id = a.customer_id
            WHERE  a.status = 'ACTIVE'
            ORDER  BY a.created_date DESC
            FETCH FIRST 50 ROWS ONLY
            """;
        String result = conv.convert(1, "Q001", sybase).getConvertedSql();

        assertTrue(result.contains("ISNULL(c.last_name, 'N/A')"), "NVL→ISNULL: " + result);
        assertTrue(result.contains(" + "), "||→+: " + result);
        assertTrue(result.contains("LEN(a.account_number)"), "LENGTH→LEN: " + result);
        assertTrue(result.contains("FORMAT(a.created_date, 'YYYY-MM-DD')"), "DATEFORMAT→FORMAT: " + result);
        assertTrue(result.contains("CAST(GETDATE() AS DATE)"), "TODAY()→CAST(GETDATE()): " + result);
        assertTrue(result.contains("TOP 50"), "FETCH FIRST→TOP: " + result);
        assertFalse(result.contains("FETCH FIRST"), "Should not contain FETCH FIRST: " + result);
    }

    @Test @DisplayName("LIST aggregate query")
    void testRealWorldListQuery() {
        String sybase = """
            SELECT branch_code,
                   LIST(TRIM(account_name), ' | ')     AS pipe_names,
                   COUNT(*)                             AS total,
                   NVL(SUM(balance), 0)                AS total_balance
            FROM   accounts
            WHERE  status <> 'CLOSED'
            GROUP  BY branch_code
            """;
        String result = conv.convert(1, "Q002", sybase).getConvertedSql();

        assertTrue(result.contains("STRING_AGG("), "LIST→STRING_AGG: " + result);
        assertTrue(result.contains("LTRIM(RTRIM(account_name))"), "TRIM: " + result);
        assertTrue(result.contains("ISNULL(SUM(balance), 0)"), "NVL→ISNULL: " + result);
    }

    @Test @DisplayName("DECODE + date functions query")
    void testRealWorldDecodeQuery() {
        String sybase = """
            SELECT transaction_id,
                   DECODE(status, 'P', 'Pending', 'C', 'Completed', 'F', 'Failed', 'Unknown'),
                   ADD_MONTHS(transaction_date, 1)  AS next_month,
                   MONTHS_BETWEEN(NOW(), transaction_date) AS months_ago
            FROM   transactions
            """;
        String result = conv.convert(1, "Q003", sybase).getConvertedSql();

        assertTrue(result.contains("CASE"), "DECODE→CASE: " + result);
        assertTrue(result.contains("DATEADD(MONTH"), "ADD_MONTHS→DATEADD: " + result);
        assertTrue(result.contains("DATEDIFF(MONTH"), "MONTHS_BETWEEN→DATEDIFF: " + result);
        assertTrue(result.contains("GETDATE()"), "NOW()→GETDATE(): " + result);
    }
}
