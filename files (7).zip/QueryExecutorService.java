package com.sqlmigration.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;

/**
 * QueryExecutorService
 * ─────────────────────────────────────────────────────────────────────────────
 * Executes an arbitrary SQL string on the target database (Sybase IQ or MS SQL)
 * and returns a normalised result set as  List<Map<String,Object>>.
 *
 * Features:
 *   • Per-query timeout (configurable via migration.query-timeout-seconds)
 *   • Max-row cap to avoid out-of-memory on huge result sets
 *   • Full exception capture with error message preserved in result
 *   • Elapsed time measurement
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class QueryExecutorService {

    @Qualifier("sybaseJdbcTemplate")
    private final JdbcTemplate sybaseJdbcTemplate;

    @Qualifier("mssqlJdbcTemplate")
    private final JdbcTemplate mssqlJdbcTemplate;

    @Value("${migration.query-timeout-seconds:120}")
    private int queryTimeoutSeconds;

    @Value("${migration.max-rows-to-compare:10000}")
    private int maxRows;

    // ── Public methods ─────────────────────────────────────────────────────────

    public QueryExecutionResult executeOnSybase(String sql) {
        return execute(sybaseJdbcTemplate, sql, "Sybase IQ");
    }

    public QueryExecutionResult executeOnMssql(String sql) {
        return execute(mssqlJdbcTemplate, sql, "MS SQL Server");
    }

    // ── Core executor ──────────────────────────────────────────────────────────

    private QueryExecutionResult execute(JdbcTemplate jdbc, String sql, String dbLabel) {
        long start = System.currentTimeMillis();

        try {
            // Execute using raw connection to set statement timeout
            return jdbc.execute((Connection conn) -> {
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setQueryTimeout(queryTimeoutSeconds);

                    boolean hasResultSet = ps.execute();
                    if (!hasResultSet) {
                        // DDL or DML — no rows to compare
                        return buildResult(dbLabel, sql,
                            QueryExecutionResult.Status.SUCCESS,
                            List.of(), List.of(),
                            System.currentTimeMillis() - start, null);
                    }

                    try (ResultSet rs = ps.getResultSet()) {
                        ResultSetMetaData meta    = rs.getMetaData();
                        int              colCount = meta.getColumnCount();

                        // ── Column names ────────────────────────────────────
                        List<String> columns = new ArrayList<>(colCount);
                        for (int c = 1; c <= colCount; c++) {
                            columns.add(meta.getColumnLabel(c)
                                .toUpperCase(Locale.ROOT));
                        }

                        // ── Rows ─────────────────────────────────────────────
                        List<Map<String, Object>> rows = new ArrayList<>();
                        int rowNum = 0;
                        while (rs.next() && rowNum < maxRows) {
                            Map<String, Object> row = new LinkedHashMap<>();
                            for (int c = 1; c <= colCount; c++) {
                                Object val = normalise(rs.getObject(c));
                                row.put(columns.get(c - 1), val);
                            }
                            rows.add(row);
                            rowNum++;
                        }

                        if (rowNum == maxRows && rs.next()) {
                            log.warn("[{}] Result truncated at {} rows for query: {}",
                                dbLabel, maxRows, abbrev(sql));
                        }

                        long elapsed = System.currentTimeMillis() - start;
                        log.info("[{}] Query returned {} rows in {}ms: {}",
                            dbLabel, rows.size(), elapsed, abbrev(sql));

                        return buildResult(dbLabel, sql,
                            QueryExecutionResult.Status.SUCCESS,
                            columns, rows, elapsed, null);
                    }
                } catch (SQLTimeoutException ex) {
                    long elapsed = System.currentTimeMillis() - start;
                    log.error("[{}] Query TIMEOUT after {}s: {}", dbLabel, queryTimeoutSeconds, abbrev(sql));
                    return buildResult(dbLabel, sql,
                        QueryExecutionResult.Status.TIMEOUT,
                        List.of(), List.of(), elapsed,
                        "Timeout after " + queryTimeoutSeconds + "s: " + ex.getMessage());
                } catch (SQLException ex) {
                    long elapsed = System.currentTimeMillis() - start;
                    log.error("[{}] SQL ERROR: {} | Query: {}", dbLabel, ex.getMessage(), abbrev(sql));
                    return buildResult(dbLabel, sql,
                        QueryExecutionResult.Status.ERROR,
                        List.of(), List.of(), elapsed,
                        "SQL-" + ex.getErrorCode() + ": " + ex.getMessage());
                }
            });

        } catch (Exception ex) {
            long elapsed = System.currentTimeMillis() - start;
            log.error("[{}] Execution exception: {}", dbLabel, ex.getMessage(), ex);
            return buildResult(dbLabel, sql,
                QueryExecutionResult.Status.ERROR,
                List.of(), List.of(), elapsed,
                ex.getClass().getSimpleName() + ": " + ex.getMessage());
        }
    }

    // ── Builders ───────────────────────────────────────────────────────────────

    private QueryExecutionResult buildResult(
            String dbLabel, String sql,
            QueryExecutionResult.Status status,
            List<String> columns,
            List<Map<String, Object>> rows,
            long elapsedMs,
            String errorMsg) {

        return QueryExecutionResult.builder()
            .status(status)
            .database(dbLabel)
            .sqlExecuted(sql)
            .columns(columns)
            .rows(rows)
            .rowCount(rows.size())
            .executionTimeMs(elapsedMs)
            .errorMessage(errorMsg)
            .executedAt(LocalDateTime.now())
            .build();
    }

    // ── Utilities ──────────────────────────────────────────────────────────────

    /**
     * Normalise an Object from JDBC to a stable representation.
     * Converts numeric types to BigDecimal string for consistent comparison.
     */
    private Object normalise(Object val) {
        if (val == null) return null;
        // Sybase & MSSQL may return slightly different numeric types
        if (val instanceof Number n) {
            // Represent as plain string with fixed decimal places
            return String.valueOf(((Number) val).doubleValue());
        }
        if (val instanceof java.sql.Timestamp ts) {
            return ts.toLocalDateTime().toString();
        }
        if (val instanceof java.sql.Date d) {
            return d.toLocalDate().toString();
        }
        if (val instanceof byte[] b) {
            return Base64.getEncoder().encodeToString(b);
        }
        return val.toString().trim();
    }

    private String abbrev(String sql) {
        if (sql == null) return "";
        return sql.length() > 100 ? sql.substring(0, 100) + "…" : sql;
    }
}

// ── Inner result class (kept in same file for cohesion) ────────────────────────

class QueryExecutionResult {

    public enum Status { SUCCESS, ERROR, TIMEOUT }

    private Status                     status;
    private String                     database;
    private String                     sqlExecuted;
    private List<String>               columns;
    private List<Map<String, Object>>  rows;
    private int                        rowCount;
    private long                       executionTimeMs;
    private String                     errorMessage;
    private java.time.LocalDateTime    executedAt;

    // Lombok @Builder-style manual builder
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private final QueryExecutionResult r = new QueryExecutionResult();
        public Builder status(Status v)                         { r.status = v;          return this; }
        public Builder database(String v)                       { r.database = v;        return this; }
        public Builder sqlExecuted(String v)                    { r.sqlExecuted = v;     return this; }
        public Builder columns(List<String> v)                  { r.columns = v;         return this; }
        public Builder rows(List<Map<String, Object>> v)        { r.rows = v;            return this; }
        public Builder rowCount(int v)                          { r.rowCount = v;        return this; }
        public Builder executionTimeMs(long v)                  { r.executionTimeMs = v; return this; }
        public Builder errorMessage(String v)                   { r.errorMessage = v;    return this; }
        public Builder executedAt(java.time.LocalDateTime v)    { r.executedAt = v;      return this; }
        public QueryExecutionResult build()                     { return r; }
    }

    // Getters
    public Status                     getStatus()          { return status; }
    public String                     getDatabase()        { return database; }
    public String                     getSqlExecuted()     { return sqlExecuted; }
    public List<String>               getColumns()         { return columns; }
    public List<Map<String, Object>>  getRows()            { return rows; }
    public int                        getRowCount()        { return rowCount; }
    public long                       getExecutionTimeMs() { return executionTimeMs; }
    public String                     getErrorMessage()    { return errorMessage; }
    public java.time.LocalDateTime    getExecutedAt()      { return executedAt; }
}
