-- ============================================================
--  queries.sql  —  100 Sybase IQ queries
--  Each query is separated by a semicolon on its own line (;)
--  The loader strips comments and blank lines automatically.
-- ============================================================

-- Q001: Basic SELECT with filter
SELECT account_id, account_name, balance, currency_code
FROM   dbo.accounts
WHERE  status = 'ACTIVE'
ORDER  BY account_name;

-- Q002: NVL (Sybase IQ null-coalescing)
SELECT customer_id,
       NVL(phone_number, 'N/A')    AS phone,
       NVL(email, 'unknown@bank.com') AS email
FROM   dbo.customers;

-- Q003: String concatenation with || operator
SELECT first_name || ' ' || last_name AS full_name,
       customer_id
FROM   dbo.customers
WHERE  country_code = 'SG';

-- Q004: IFNULL function
SELECT transaction_id,
       IFNULL(remarks, 'No remarks') AS remarks,
       amount
FROM   dbo.transactions
WHERE  transaction_date >= '2024-01-01';

-- Q005: LENGTH function
SELECT account_id,
       LENGTH(account_name) AS name_length
FROM   dbo.accounts
WHERE  LENGTH(account_name) > 20;

-- Q006: LOCATE function
SELECT description,
       LOCATE('PAYMENT', UPPER(description)) AS pay_pos
FROM   dbo.transactions
WHERE  LOCATE('PAYMENT', UPPER(description)) > 0;

-- Q007: SUBSTR function
SELECT customer_id,
       SUBSTR(id_number, 1, 3)  AS id_prefix,
       SUBSTR(id_number, 4)     AS id_suffix
FROM   dbo.customers;

-- Q008: TODAY() function
SELECT transaction_id, amount, currency_code
FROM   dbo.transactions
WHERE  CAST(transaction_date AS DATE) = TODAY();

-- Q009: NOW() function
SELECT account_id,
       NOW() AS snapshot_time,
       balance
FROM   dbo.accounts
WHERE  balance > 10000;

-- Q010: DATEFORMAT function
SELECT transaction_id,
       DATEFORMAT(transaction_date, 'YYYY-MM-DD') AS txn_date_str,
       amount
FROM   dbo.transactions
ORDER  BY transaction_date DESC;

-- Q011: MOD function
SELECT account_id, balance
FROM   dbo.accounts
WHERE  MOD(account_id, 2) = 0;

-- Q012: LIST aggregate
SELECT branch_code,
       LIST(account_id, ', ') AS account_ids
FROM   dbo.accounts
GROUP  BY branch_code;

-- Q013: TRIM function
SELECT customer_id,
       TRIM(first_name) AS first_name,
       TRIM(last_name)  AS last_name
FROM   dbo.customers;

-- Q014: DECODE function
SELECT transaction_id,
       DECODE(status, 'P', 'Pending', 'C', 'Completed', 'F', 'Failed', 'Unknown') AS status_desc
FROM   dbo.transactions;

-- Q015: TOP with ORDER BY
SELECT TOP 10 account_id, balance
FROM   dbo.accounts
ORDER  BY balance DESC;

-- Q016: DATEADD days
SELECT transaction_id, amount,
       DATEADD(day, 30, transaction_date) AS due_date
FROM   dbo.transactions
WHERE  status = 'PENDING';

-- Q017: DATEDIFF days
SELECT account_id,
       DATEDIFF(day, created_date, GETDATE()) AS account_age_days
FROM   dbo.accounts;

-- Q018: YEAR / MONTH / DAY extract
SELECT YEAR(transaction_date)  AS txn_year,
       MONTH(transaction_date) AS txn_month,
       DAY(transaction_date)   AS txn_day,
       SUM(amount)             AS total
FROM   dbo.transactions
GROUP  BY YEAR(transaction_date), MONTH(transaction_date), DAY(transaction_date);

-- Q019: CASE WHEN expression
SELECT account_id,
       balance,
       CASE
           WHEN balance >= 100000 THEN 'Platinum'
           WHEN balance >= 50000  THEN 'Gold'
           WHEN balance >= 10000  THEN 'Silver'
           ELSE 'Standard'
       END AS tier
FROM   dbo.accounts;

-- Q020: COALESCE across columns
SELECT customer_id,
       COALESCE(mobile_number, home_number, office_number, 'N/A') AS contact
FROM   dbo.customers;

-- Q021: COUNT DISTINCT
SELECT branch_code,
       COUNT(DISTINCT customer_id) AS unique_customers,
       COUNT(*)                    AS total_accounts
FROM   dbo.accounts
GROUP  BY branch_code
ORDER  BY unique_customers DESC;

-- Q022: SUM with CASE
SELECT currency_code,
       SUM(CASE WHEN transaction_type = 'CREDIT' THEN amount ELSE 0 END) AS total_credits,
       SUM(CASE WHEN transaction_type = 'DEBIT'  THEN amount ELSE 0 END) AS total_debits
FROM   dbo.transactions
GROUP  BY currency_code;

-- Q023: EXISTS subquery
SELECT c.customer_id, c.first_name, c.last_name
FROM   dbo.customers c
WHERE  EXISTS (
           SELECT 1
           FROM   dbo.accounts a
           WHERE  a.customer_id = c.customer_id
             AND  a.balance > 50000
       );

-- Q024: NOT EXISTS subquery
SELECT c.customer_id, c.first_name
FROM   dbo.customers c
WHERE  NOT EXISTS (
           SELECT 1
           FROM   dbo.transactions t
           WHERE  t.customer_id = c.customer_id
             AND  t.transaction_date >= DATEADD(day, -90, TODAY())
       );

-- Q025: LEFT JOIN with NVL
SELECT a.account_id,
       a.account_name,
       NVL(l.credit_limit, 0) AS credit_limit
FROM   dbo.accounts a
LEFT   JOIN dbo.loan_accounts l ON l.account_id = a.account_id;

-- Q026: INNER JOIN three tables
SELECT c.customer_id,
       c.first_name || ' ' || c.last_name AS name,
       a.account_id,
       t.amount
FROM   dbo.customers     c
JOIN   dbo.accounts      a ON a.customer_id = c.customer_id
JOIN   dbo.transactions  t ON t.account_id  = a.account_id
WHERE  t.transaction_date >= '2024-01-01';

-- Q027: Aggregate with HAVING
SELECT account_id,
       COUNT(*) AS txn_count,
       SUM(amount) AS total_amount
FROM   dbo.transactions
GROUP  BY account_id
HAVING COUNT(*) > 10;

-- Q028: Scalar subquery in SELECT
SELECT a.account_id,
       a.balance,
       (SELECT COUNT(*) FROM dbo.transactions t
        WHERE t.account_id = a.account_id) AS txn_count
FROM   dbo.accounts a;

-- Q029: IN clause with subquery
SELECT customer_id, first_name, last_name
FROM   dbo.customers
WHERE  customer_id IN (
           SELECT DISTINCT customer_id
           FROM   dbo.accounts
           WHERE  status = 'DORMANT'
       );

-- Q030: BETWEEN clause
SELECT transaction_id, amount, transaction_date
FROM   dbo.transactions
WHERE  amount BETWEEN 1000 AND 50000
  AND  transaction_date BETWEEN '2024-01-01' AND '2024-12-31';

-- Q031: LIKE pattern matching
SELECT customer_id, email
FROM   dbo.customers
WHERE  email LIKE '%@gmail.com'
   OR  email LIKE '%@yahoo.com';

-- Q032: UPPER / LOWER
SELECT customer_id,
       UPPER(first_name) AS first_upper,
       LOWER(last_name)  AS last_lower
FROM   dbo.customers;

-- Q033: ROUND function
SELECT transaction_id,
       amount,
       ROUND(amount * 0.08, 2) AS gst_amount,
       ROUND(amount * 1.08, 2) AS total_with_gst
FROM   dbo.transactions
WHERE  taxable = 1;

-- Q034: ISNULL / NVL in WHERE
SELECT account_id, account_name
FROM   dbo.accounts
WHERE  NVL(closed_date, '9999-12-31') > TODAY();

-- Q035: FLOOR and CEILING
SELECT transaction_id,
       amount,
       FLOOR(amount)   AS floor_amt,
       CEILING(amount) AS ceil_amt
FROM   dbo.transactions;

-- Q036: ABS function
SELECT account_id,
       ABS(balance - avg_balance) AS deviation
FROM   dbo.account_snapshots
WHERE  ABS(balance - avg_balance) > 5000;

-- Q037: CAST to different types
SELECT transaction_id,
       CAST(amount AS INTEGER)       AS amount_int,
       CAST(transaction_date AS DATE) AS txn_date
FROM   dbo.transactions;

-- Q038: CONVERT date format (Sybase)
SELECT account_id,
       CONVERT(VARCHAR(10), created_date, 23) AS created_yyyymmdd
FROM   dbo.accounts;

-- Q039: ROW_NUMBER window function
SELECT account_id, customer_id, balance,
       ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY balance DESC) AS rn
FROM   dbo.accounts;

-- Q040: RANK window function
SELECT account_id, branch_code, balance,
       RANK() OVER (PARTITION BY branch_code ORDER BY balance DESC) AS rnk
FROM   dbo.accounts;

-- Q041: DENSE_RANK window function
SELECT customer_id, transaction_date, amount,
       DENSE_RANK() OVER (ORDER BY amount DESC) AS dr
FROM   dbo.transactions;

-- Q042: LAG window function
SELECT account_id, transaction_date, balance,
       LAG(balance, 1, 0) OVER (PARTITION BY account_id ORDER BY transaction_date) AS prev_balance
FROM   dbo.account_snapshots;

-- Q043: LEAD window function
SELECT account_id, transaction_date, balance,
       LEAD(balance, 1) OVER (PARTITION BY account_id ORDER BY transaction_date) AS next_balance
FROM   dbo.account_snapshots;

-- Q044: SUM window function (running total)
SELECT account_id, transaction_date, amount,
       SUM(amount) OVER (PARTITION BY account_id ORDER BY transaction_date
                         ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_total
FROM   dbo.transactions;

-- Q045: AVG window function
SELECT branch_code, account_id, balance,
       AVG(balance) OVER (PARTITION BY branch_code) AS avg_branch_balance
FROM   dbo.accounts;

-- Q046: FIRST_VALUE window function
SELECT customer_id, account_id, created_date,
       FIRST_VALUE(account_id) OVER (PARTITION BY customer_id ORDER BY created_date) AS first_account
FROM   dbo.accounts;

-- Q047: LAST_VALUE window function
SELECT customer_id, account_id, created_date,
       LAST_VALUE(account_id) OVER (PARTITION BY customer_id ORDER BY created_date
                                    ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS last_account
FROM   dbo.accounts;

-- Q048: CTE (Common Table Expression)
WITH ranked_accounts AS (
    SELECT account_id, customer_id, balance,
           RANK() OVER (PARTITION BY customer_id ORDER BY balance DESC) AS rnk
    FROM   dbo.accounts
    WHERE  status = 'ACTIVE'
)
SELECT account_id, customer_id, balance
FROM   ranked_accounts
WHERE  rnk = 1;

-- Q049: Recursive CTE (org hierarchy)
WITH RECURSIVE org_tree AS (
    SELECT employee_id, manager_id, employee_name, 0 AS level
    FROM   dbo.employees
    WHERE  manager_id IS NULL
    UNION ALL
    SELECT e.employee_id, e.manager_id, e.employee_name, o.level + 1
    FROM   dbo.employees e
    JOIN   org_tree o ON o.employee_id = e.manager_id
)
SELECT employee_id, employee_name, level
FROM   org_tree
ORDER  BY level, employee_name;

-- Q050: UNION ALL
SELECT account_id, 'SAVINGS' AS account_type, balance
FROM   dbo.savings_accounts
UNION ALL
SELECT account_id, 'CURRENT' AS account_type, balance
FROM   dbo.current_accounts;

-- Q051: UNION (distinct)
SELECT customer_id FROM dbo.savings_accounts
UNION
SELECT customer_id FROM dbo.current_accounts;

-- Q052: INTERSECT
SELECT customer_id FROM dbo.savings_accounts
INTERSECT
SELECT customer_id FROM dbo.current_accounts;

-- Q053: EXCEPT
SELECT customer_id FROM dbo.customers
EXCEPT
SELECT DISTINCT customer_id FROM dbo.accounts WHERE status = 'ACTIVE';

-- Q054: Multi-column GROUP BY with ROLLUP
SELECT branch_code, currency_code, SUM(balance) AS total_balance
FROM   dbo.accounts
GROUP  BY ROLLUP(branch_code, currency_code);

-- Q055: CUBE grouping
SELECT branch_code, currency_code, COUNT(*) AS cnt
FROM   dbo.accounts
GROUP  BY CUBE(branch_code, currency_code);

-- Q056: GROUPING SETS
SELECT branch_code, currency_code, transaction_type, SUM(amount) AS total
FROM   dbo.transactions t
JOIN   dbo.accounts a ON a.account_id = t.account_id
GROUP  BY GROUPING SETS ((branch_code, currency_code), (transaction_type), ());

-- Q057: Correlated subquery
SELECT a.account_id, a.balance
FROM   dbo.accounts a
WHERE  a.balance > (
           SELECT AVG(a2.balance)
           FROM   dbo.accounts a2
           WHERE  a2.branch_code = a.branch_code
       );

-- Q058: PIVOT simulation with CASE
SELECT branch_code,
       SUM(CASE WHEN currency_code = 'SGD' THEN balance ELSE 0 END) AS sgd_total,
       SUM(CASE WHEN currency_code = 'USD' THEN balance ELSE 0 END) AS usd_total,
       SUM(CASE WHEN currency_code = 'EUR' THEN balance ELSE 0 END) AS eur_total
FROM   dbo.accounts
GROUP  BY branch_code;

-- Q059: String REPLACE
SELECT transaction_id,
       REPLACE(description, 'TXN', 'TRANSACTION') AS full_description
FROM   dbo.transactions;

-- Q060: LEFT / RIGHT string functions
SELECT account_id,
       LEFT(account_number, 4)  AS bank_code,
       RIGHT(account_number, 6) AS serial_no
FROM   dbo.accounts;

-- Q061: CHARINDEX (MSSQL-style, also works in Sybase IQ)
SELECT transaction_id, description,
       CHARINDEX('REF', description) AS ref_position
FROM   dbo.transactions
WHERE  CHARINDEX('REF', description) > 0;

-- Q062: REPLICATE / REPEAT padding
SELECT account_id,
       REPLICATE('0', 10 - LENGTH(CAST(account_id AS VARCHAR))) || CAST(account_id AS VARCHAR) AS padded_id
FROM   dbo.accounts;

-- Q063: STUFF / OVERLAY
SELECT transaction_id,
       STUFF(reference_number, 5, 4, '****') AS masked_ref
FROM   dbo.transactions;

-- Q064: ISNUMERIC check
SELECT customer_id, id_number
FROM   dbo.customers
WHERE  ISNUMERIC(id_number) = 1;

-- Q065: NULLIF function
SELECT account_id,
       NULLIF(remarks, '') AS remarks_clean
FROM   dbo.accounts;

-- Q066: GREATEST equivalent (Sybase IQ CASE)
SELECT account_id,
       CASE
           WHEN balance >= last_month_balance THEN balance
           ELSE last_month_balance
       END AS max_balance
FROM   dbo.account_snapshots;

-- Q067: LEAST equivalent
SELECT account_id,
       CASE
           WHEN balance <= min_balance THEN balance
           ELSE min_balance
       END AS actual_min
FROM   dbo.account_snapshots;

-- Q068: Multi-row INSERT select
SELECT 'REPORT_' || CAST(account_id AS VARCHAR) AS report_key,
       account_id,
       balance,
       TODAY() AS report_date
FROM   dbo.accounts
WHERE  balance > 100000;

-- Q069: Nested CASE
SELECT transaction_id, amount,
       CASE transaction_type
           WHEN 'CREDIT' THEN
               CASE WHEN amount > 10000 THEN 'Large Credit' ELSE 'Small Credit' END
           WHEN 'DEBIT' THEN
               CASE WHEN amount > 10000 THEN 'Large Debit'  ELSE 'Small Debit'  END
           ELSE 'Other'
       END AS txn_category
FROM   dbo.transactions;

-- Q070: Date truncation (TRUNC to month)
SELECT DATEFORMAT(transaction_date, 'YYYY-MM-01') AS month_start,
       COUNT(*) AS txn_count,
       SUM(amount) AS total
FROM   dbo.transactions
GROUP  BY DATEFORMAT(transaction_date, 'YYYY-MM-01')
ORDER  BY month_start;

-- Q071: String splitting simulation
SELECT customer_id,
       SUBSTR(full_address, 1, LOCATE(',', full_address) - 1) AS street,
       SUBSTR(full_address, LOCATE(',', full_address) + 1)    AS city_zip
FROM   dbo.customers
WHERE  LOCATE(',', full_address) > 0;

-- Q072: Aggregate filter (HAVING with multiple conditions)
SELECT account_id,
       COUNT(*) AS txn_count,
       MAX(amount) AS max_txn,
       SUM(amount) AS total
FROM   dbo.transactions
GROUP  BY account_id
HAVING COUNT(*) > 5
   AND SUM(amount) > 100000;

-- Q073: Self join (find same-customer accounts)
SELECT a1.account_id AS account1,
       a2.account_id AS account2,
       a1.customer_id
FROM   dbo.accounts a1
JOIN   dbo.accounts a2 ON  a1.customer_id = a2.customer_id
                       AND a1.account_id  < a2.account_id;

-- Q074: CROSS JOIN sample
SELECT c.currency_code, b.branch_code
FROM   dbo.currencies c
CROSS  JOIN dbo.branches b;

-- Q075: Percent calculation
SELECT branch_code,
       COUNT(*) AS branch_accounts,
       ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM dbo.accounts), 2) AS pct
FROM   dbo.accounts
GROUP  BY branch_code;

-- Q076: Date range partitioning query
SELECT CASE
           WHEN transaction_date < '2024-04-01' THEN 'Q1'
           WHEN transaction_date < '2024-07-01' THEN 'Q2'
           WHEN transaction_date < '2024-10-01' THEN 'Q3'
           ELSE 'Q4'
       END AS quarter,
       SUM(amount) AS total
FROM   dbo.transactions
WHERE  YEAR(transaction_date) = 2024
GROUP  BY CASE
           WHEN transaction_date < '2024-04-01' THEN 'Q1'
           WHEN transaction_date < '2024-07-01' THEN 'Q2'
           WHEN transaction_date < '2024-10-01' THEN 'Q3'
           ELSE 'Q4'
       END;

-- Q077: NTH_VALUE window
SELECT account_id, balance,
       NTH_VALUE(balance, 3) OVER (ORDER BY balance DESC
                                   ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS third_highest
FROM   dbo.accounts;

-- Q078: NTILE window
SELECT account_id, balance,
       NTILE(4) OVER (ORDER BY balance) AS quartile
FROM   dbo.accounts;

-- Q079: PERCENT_RANK
SELECT account_id, balance,
       ROUND(PERCENT_RANK() OVER (ORDER BY balance) * 100, 2) AS percentile
FROM   dbo.accounts;

-- Q080: CUME_DIST
SELECT account_id, balance,
       ROUND(CUME_DIST() OVER (ORDER BY balance) * 100, 2) AS cume_pct
FROM   dbo.accounts;

-- Q081: FULL OUTER JOIN
SELECT NVL(s.customer_id, c.customer_id) AS customer_id,
       s.savings_balance,
       c.current_balance
FROM   dbo.savings_accounts  s
FULL   OUTER JOIN dbo.current_accounts c ON c.customer_id = s.customer_id;

-- Q082: Conditional aggregation
SELECT branch_code,
       COUNT(CASE WHEN status = 'ACTIVE'  THEN 1 END) AS active_cnt,
       COUNT(CASE WHEN status = 'DORMANT' THEN 1 END) AS dormant_cnt,
       COUNT(CASE WHEN status = 'CLOSED'  THEN 1 END) AS closed_cnt
FROM   dbo.accounts
GROUP  BY branch_code;

-- Q083: Moving average
SELECT account_id, transaction_date, amount,
       AVG(amount) OVER (PARTITION BY account_id
                         ORDER BY transaction_date
                         ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS moving_avg_7
FROM   dbo.transactions;

-- Q084: Deduplication using ROW_NUMBER
SELECT *
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY customer_id, transaction_date
                              ORDER BY created_timestamp DESC) AS rn
    FROM   dbo.transactions
) t
WHERE  rn = 1;

-- Q085: Outer apply simulation (lateral join)
SELECT a.account_id, t.last_txn_date, t.last_amount
FROM   dbo.accounts a
JOIN (
    SELECT account_id,
           MAX(transaction_date) AS last_txn_date,
           SUM(amount)           AS last_amount
    FROM   dbo.transactions
    GROUP  BY account_id
) t ON t.account_id = a.account_id;

-- Q086: Multiple CTEs chained
WITH active_accounts AS (
    SELECT account_id, customer_id, balance
    FROM   dbo.accounts
    WHERE  status = 'ACTIVE'
),
high_value AS (
    SELECT account_id, customer_id, balance
    FROM   active_accounts
    WHERE  balance > 50000
),
customer_info AS (
    SELECT c.customer_id, c.first_name || ' ' || c.last_name AS full_name
    FROM   dbo.customers c
)
SELECT h.account_id, ci.full_name, h.balance
FROM   high_value h
JOIN   customer_info ci ON ci.customer_id = h.customer_id;

-- Q087: DATEADD and DATEDIFF combined
SELECT account_id,
       DATEDIFF(month, created_date, NOW()) AS months_old,
       DATEADD(year, 1, created_date)       AS one_year_anniversary
FROM   dbo.accounts
WHERE  DATEDIFF(month, created_date, NOW()) < 12;

-- Q088: CONCAT (some Sybase IQ versions)
SELECT customer_id,
       first_name || ' ' || NVL(middle_name || ' ', '') || last_name AS display_name
FROM   dbo.customers;

-- Q089: NUMERIC formatting with ROUND
SELECT transaction_id,
       ROUND(amount, 0)  AS whole_amount,
       ROUND(amount, 2)  AS two_decimal,
       ROUND(amount, -3) AS nearest_thousand
FROM   dbo.transactions;

-- Q090: Pivot-like with MAX(CASE)
SELECT customer_id,
       MAX(CASE WHEN preference_type = 'EMAIL'  THEN preference_value END) AS email_pref,
       MAX(CASE WHEN preference_type = 'SMS'    THEN preference_value END) AS sms_pref,
       MAX(CASE WHEN preference_type = 'PUSH'   THEN preference_value END) AS push_pref
FROM   dbo.customer_preferences
GROUP  BY customer_id;

-- Q091: Hierarchical balance rollup
SELECT branch_code,
       SUM(balance) AS branch_total,
       SUM(SUM(balance)) OVER () AS grand_total,
       ROUND(SUM(balance) * 100.0 / SUM(SUM(balance)) OVER (), 2) AS pct
FROM   dbo.accounts
WHERE  status = 'ACTIVE'
GROUP  BY branch_code;

-- Q092: Gaps and islands (detect consecutive dates)
SELECT account_id,
       transaction_date,
       DATEDIFF(day,
           LAG(transaction_date) OVER (PARTITION BY account_id ORDER BY transaction_date),
           transaction_date) AS days_gap
FROM   dbo.transactions;

-- Q093: String aggregation LIST with ORDER
SELECT branch_code,
       LIST(account_name ORDER BY account_name, ', ') AS sorted_accounts
FROM   dbo.accounts
GROUP  BY branch_code;

-- Q094: DATEPART equivalent
SELECT transaction_id,
       DATEPART(weekday, transaction_date) AS day_of_week,
       DATEPART(week, transaction_date)    AS week_of_year
FROM   dbo.transactions;

-- Q095: SOUNDEX for fuzzy name matching
SELECT c1.customer_id AS id1,
       c2.customer_id AS id2,
       c1.last_name   AS name1,
       c2.last_name   AS name2
FROM   dbo.customers c1
JOIN   dbo.customers c2 ON  SOUNDEX(c1.last_name) = SOUNDEX(c2.last_name)
                         AND c1.customer_id < c2.customer_id;

-- Q096: TRANSLATE function
SELECT transaction_id,
       TRANSLATE(reference_number, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
                                   'abcdefghijklmnopqrstuvwxyz') AS ref_lower
FROM   dbo.transactions;

-- Q097: Aggregate over date bucket
SELECT DATEFORMAT(transaction_date, 'YYYY-MM') AS month,
       currency_code,
       COUNT(*)        AS txn_count,
       SUM(amount)     AS total_amount,
       AVG(amount)     AS avg_amount,
       MIN(amount)     AS min_amount,
       MAX(amount)     AS max_amount,
       STDEV(amount)   AS std_dev
FROM   dbo.transactions
GROUP  BY DATEFORMAT(transaction_date, 'YYYY-MM'), currency_code
ORDER  BY month, currency_code;

-- Q098: Matching orphan records
SELECT a.account_id, a.customer_id
FROM   dbo.accounts a
WHERE  NOT EXISTS (
           SELECT 1
           FROM   dbo.customers c
           WHERE  c.customer_id = a.customer_id
       );

-- Q099: Complex multi-join with window
SELECT c.customer_id,
       c.first_name || ' ' || c.last_name AS name,
       COUNT(DISTINCT a.account_id)        AS account_count,
       SUM(a.balance)                      AS total_balance,
       SUM(SUM(a.balance)) OVER ()         AS portfolio_total,
       ROUND(SUM(a.balance) * 100.0 / SUM(SUM(a.balance)) OVER (), 4) AS share_pct
FROM   dbo.customers c
JOIN   dbo.accounts  a ON a.customer_id = c.customer_id
WHERE  a.status = 'ACTIVE'
GROUP  BY c.customer_id, c.first_name, c.last_name;

-- Q100: Final summary dashboard query
SELECT 'TOTAL_CUSTOMERS'  AS metric, COUNT(*)          AS value FROM dbo.customers
UNION ALL
SELECT 'ACTIVE_ACCOUNTS',             COUNT(*)          FROM dbo.accounts      WHERE status = 'ACTIVE'
UNION ALL
SELECT 'TOTAL_BALANCE',               ROUND(SUM(balance),2) FROM dbo.accounts  WHERE status = 'ACTIVE'
UNION ALL
SELECT 'TRANSACTIONS_TODAY',          COUNT(*)          FROM dbo.transactions  WHERE CAST(transaction_date AS DATE) = TODAY()
UNION ALL
SELECT 'TOTAL_BRANCHES',              COUNT(DISTINCT branch_code) FROM dbo.accounts;
