package com.sqlmigration.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

/**
 * HtmlReportGeneratorService
 * ─────────────────────────────────────────────────────────────────────────────
 * Generates a self-contained, single-file HTML report with:
 *
 *   • Executive summary card (PASS / FAIL / ERROR counts + donut chart)
 *   • Searchable, filterable query table
 *   • Per-query expandable detail:
 *       – Original Sybase IQ SQL
 *       – Converted MS SQL (diff-highlighted)
 *       – Conversion notes (what changed)
 *       – Execution times for both DBs
 *       – Row/column count comparison
 *       – Cell-level diff table (red = mismatch, green = match)
 *   • Full CSS embedded (zero external dependencies)
 */
@Service
@Slf4j
public class HtmlReportGeneratorService {

    public String generateHtmlReport(MigrationReport report, String outputDir) throws IOException {
        Path dir = Paths.get(outputDir);
        Files.createDirectories(dir);
        String filename = "migration-report-" + report.getGeneratedAt()
            .replace(":", "").replace(" ", "_") + ".html";
        Path outPath = dir.resolve(filename);

        String html = buildHtml(report);
        Files.writeString(outPath, html, StandardCharsets.UTF_8);
        log.info("HTML report written to: {}", outPath.toAbsolutePath());
        return outPath.toAbsolutePath().toString();
    }

    // ── HTML builder ───────────────────────────────────────────────────────────

    private String buildHtml(MigrationReport r) {
        double passRate = r.getTotalQueries() == 0 ? 0 :
            (r.getPassed() * 100.0 / r.getTotalQueries());

        StringBuilder sb = new StringBuilder();
        sb.append(htmlHead());
        sb.append("<body>\n");
        sb.append(buildHeader(r));
        sb.append(buildSummaryCards(r, passRate));
        sb.append(buildFilterBar());
        sb.append(buildQueryTable(r.getResults()));
        sb.append(buildDetailSections(r.getResults()));
        sb.append(buildFooter(r));
        sb.append(buildScript());
        sb.append("</body></html>");
        return sb.toString();
    }

    // ── Header ─────────────────────────────────────────────────────────────────

    private String buildHeader(MigrationReport r) {
        return """
            <header class="site-header">
              <div class="header-inner">
                <div class="logo">
                  <span class="logo-db">DB</span>
                  <span class="logo-text">Migration Validator</span>
                </div>
                <div class="header-meta">
                  <span>Sybase IQ → MS SQL Server</span>
                  <span class="sep">|</span>
                  <span>Generated: %s</span>
                  <span class="sep">|</span>
                  <span>%d queries</span>
                </div>
              </div>
            </header>
            """.formatted(r.getGeneratedAt(), r.getTotalQueries());
    }

    // ── Summary cards ──────────────────────────────────────────────────────────

    private String buildSummaryCards(MigrationReport r, double passRate) {
        return """
            <section class="summary">
              <div class="summary-grid">

                <div class="card card-pass">
                  <div class="card-icon">✓</div>
                  <div class="card-value">%d</div>
                  <div class="card-label">PASSED</div>
                </div>

                <div class="card card-fail">
                  <div class="card-icon">✗</div>
                  <div class="card-value">%d</div>
                  <div class="card-label">FAILED</div>
                </div>

                <div class="card card-error">
                  <div class="card-icon">!</div>
                  <div class="card-value">%d</div>
                  <div class="card-label">ERRORS</div>
                </div>

                <div class="card card-rate">
                  <div class="card-icon">%%</div>
                  <div class="card-value">%.1f</div>
                  <div class="card-label">PASS RATE</div>
                </div>

                <div class="card card-time">
                  <div class="card-icon">⏱</div>
                  <div class="card-value">%ds</div>
                  <div class="card-label">TOTAL TIME</div>
                </div>

              </div>

              <div class="dsn-row">
                <span class="dsn-label">Sybase IQ:</span> <code>%s</code>
                <span class="dsn-sep">→</span>
                <span class="dsn-label">MS SQL:</span> <code>%s</code>
              </div>
            </section>
            """.formatted(
                r.getPassed(), r.getFailed(), r.getErrors(),
                passRate,
                r.getTotalRunTimeMs() / 1000,
                esc(r.getSybaseDsn()),
                esc(r.getMssqlDsn())
            );
    }

    // ── Filter bar ─────────────────────────────────────────────────────────────

    private String buildFilterBar() {
        return """
            <section class="filter-bar">
              <input id="searchInput" type="text" placeholder="🔍  Search query label or SQL …" oninput="filterTable()">
              <select id="verdictFilter" onchange="filterTable()">
                <option value="">All verdicts</option>
                <option value="PASS">PASS</option>
                <option value="DATA_DIFF">DATA_DIFF</option>
                <option value="ROW_COUNT_DIFF">ROW_COUNT_DIFF</option>
                <option value="SCHEMA_MISMATCH">SCHEMA_MISMATCH</option>
                <option value="MSSQL_ERROR">MSSQL_ERROR</option>
                <option value="SYBASE_ERROR">SYBASE_ERROR</option>
                <option value="BOTH_ERROR">BOTH_ERROR</option>
              </select>
            </section>
            """;
    }

    // ── Query summary table ────────────────────────────────────────────────────

    private String buildQueryTable(List<ComparisonResult> results) {
        StringBuilder sb = new StringBuilder();
        sb.append("""
            <section class="table-section">
              <table id="mainTable">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Label</th>
                    <th>Verdict</th>
                    <th>Sybase Rows</th>
                    <th>MSSQL Rows</th>
                    <th>Cell Diffs</th>
                    <th>Sybase ms</th>
                    <th>MSSQL ms</th>
                    <th>Conversion Notes</th>
                    <th>Detail</th>
                  </tr>
                </thead>
                <tbody>
            """);

        for (ComparisonResult r : results) {
            String verdictClass = verdictCss(r.getVerdict().name());
            String sybaseRows   = r.getSybaseResult() != null
                ? String.valueOf(r.getSybaseResult().getRowCount()) : "—";
            String mssqlRows    = r.getMssqlResult()  != null
                ? String.valueOf(r.getMssqlResult().getRowCount())  : "—";
            long   sybaseMs     = r.getSybaseResult() != null ? r.getSybaseResult().getExecutionTimeMs() : 0;
            long   mssqlMs      = r.getMssqlResult()  != null ? r.getMssqlResult().getExecutionTimeMs()  : 0;
            int    notes        = r.getConversionNotes() != null ? r.getConversionNotes().size() : 0;

            sb.append("<tr class=\"data-row\" data-verdict=\"").append(r.getVerdict().name()).append("\"")
              .append(" data-label=\"").append(r.getQueryLabel()).append("\"")
              .append(" data-sql=\"").append(esc(abbrev(r.getOriginalSql(), 80))).append("\">\n")
              .append("<td>").append(r.getQueryNumber()).append("</td>\n")
              .append("<td><code>").append(r.getQueryLabel()).append("</code></td>\n")
              .append("<td><span class=\"badge ").append(verdictClass).append("\">")
              .append(r.getVerdict().name()).append("</span></td>\n")
              .append("<td>").append(sybaseRows).append("</td>\n")
              .append("<td>").append(mssqlRows).append("</td>\n")
              .append("<td class=\"").append(r.getTotalCellDiffs() > 0 ? "diff-cell" : "").append("\">")
              .append(r.getTotalCellDiffs()).append("</td>\n")
              .append("<td>").append(sybaseMs).append("ms</td>\n")
              .append("<td>").append(mssqlMs).append("ms</td>\n")
              .append("<td class=\"notes-count\">").append(notes).append(" rule(s)</td>\n")
              .append("<td><button class=\"btn-detail\" onclick=\"toggleDetail('d")
              .append(r.getQueryNumber()).append("')\">▶ View</button></td>\n")
              .append("</tr>\n");
        }

        sb.append("</tbody></table></section>\n");
        return sb.toString();
    }

    // ── Detail sections ────────────────────────────────────────────────────────

    private String buildDetailSections(List<ComparisonResult> results) {
        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"details\">\n");

        for (ComparisonResult r : results) {
            sb.append("<div id=\"d").append(r.getQueryNumber())
              .append("\" class=\"detail-panel\" style=\"display:none\">\n");

            sb.append("<h3>").append(r.getQueryLabel())
              .append(" &nbsp;<span class=\"badge ")
              .append(verdictCss(r.getVerdict().name())).append("\">")
              .append(r.getVerdict().name()).append("</span></h3>\n");

            // ── SQL panels side by side ──────────────────────────────────────
            sb.append("<div class=\"sql-grid\">\n");

            sb.append("<div class=\"sql-panel\">\n")
              .append("<div class=\"sql-panel-title\">🐋 Sybase IQ (Original)</div>\n")
              .append("<pre class=\"sql-block\">").append(esc(r.getOriginalSql())).append("</pre>\n")
              .append("</div>\n");

            sb.append("<div class=\"sql-panel\">\n")
              .append("<div class=\"sql-panel-title\">🟦 MS SQL Server (Converted)</div>\n")
              .append("<pre class=\"sql-block converted\">").append(esc(r.getConvertedSql())).append("</pre>\n")
              .append("</div>\n");

            sb.append("</div>\n"); // sql-grid

            // ── Conversion notes ────────────────────────────────────────────
            if (r.getConversionNotes() != null && !r.getConversionNotes().isEmpty()) {
                sb.append("<div class=\"conv-notes\"><strong>🔄 Conversion Rules Applied:</strong><ul>\n");
                for (String note : r.getConversionNotes()) {
                    sb.append("<li>").append(esc(note)).append("</li>\n");
                }
                sb.append("</ul></div>\n");
            }

            // ── Error messages ───────────────────────────────────────────────
            if (r.getSybaseResult() != null && r.getSybaseResult().getErrorMessage() != null) {
                sb.append("<div class=\"error-box\">⚠️ <strong>Sybase IQ Error:</strong> ")
                  .append(esc(r.getSybaseResult().getErrorMessage())).append("</div>\n");
            }
            if (r.getMssqlResult() != null && r.getMssqlResult().getErrorMessage() != null) {
                sb.append("<div class=\"error-box mssql-err\">⚠️ <strong>MS SQL Error:</strong> ")
                  .append(esc(r.getMssqlResult().getErrorMessage())).append("</div>\n");
            }

            // ── Schema mismatch ──────────────────────────────────────────────
            if (!r.getMissingColumnsInMssql().isEmpty()) {
                sb.append("<div class=\"schema-warn\">📋 Columns in Sybase but missing in MSSQL: <strong>")
                  .append(esc(String.join(", ", r.getMissingColumnsInMssql())))
                  .append("</strong></div>\n");
            }
            if (!r.getExtraColumnsInMssql().isEmpty()) {
                sb.append("<div class=\"schema-info\">📋 Extra columns in MSSQL: <strong>")
                  .append(esc(String.join(", ", r.getExtraColumnsInMssql())))
                  .append("</strong></div>\n");
            }

            // ── Cell diff table ──────────────────────────────────────────────
            if (r.getCellDiffs() != null && !r.getCellDiffs().isEmpty()) {
                sb.append("<h4>🔬 Cell-Level Differences (").append(r.getTotalCellDiffs())
                  .append(" mismatches)</h4>\n");
                sb.append("<div class=\"diff-table-wrap\">\n");
                sb.append("<table class=\"diff-table\">\n");
                sb.append("<thead><tr><th>Row #</th><th>Column</th><th>Sybase IQ Value</th><th>MS SQL Value</th></tr></thead>\n");
                sb.append("<tbody>\n");
                int shown = 0;
                for (CellDiff diff : r.getCellDiffs()) {
                    if (shown++ > 200) {
                        sb.append("<tr><td colspan=\"4\" class=\"truncated\">… ")
                          .append(r.getTotalCellDiffs() - 200).append(" more diffs truncated …</td></tr>\n");
                        break;
                    }
                    sb.append("<tr class=\"diff-row\">\n")
                      .append("<td>").append(diff.getRowIndex()).append("</td>\n")
                      .append("<td><code>").append(esc(diff.getColumnName())).append("</code></td>\n")
                      .append("<td class=\"val-sybase\">").append(esc(diff.getSybaseValue())).append("</td>\n")
                      .append("<td class=\"val-mssql\">").append(esc(diff.getMssqlValue())).append("</td>\n")
                      .append("</tr>\n");
                }
                sb.append("</tbody></table></div>\n");
            } else if (r.getVerdict() == ComparisonResult.Verdict.PASS) {
                sb.append("<div class=\"all-match\">✅ All rows and values match exactly.</div>\n");
            }

            sb.append("</div>\n"); // detail-panel
        }

        sb.append("</section>\n");
        return sb.toString();
    }

    // ── Footer ─────────────────────────────────────────────────────────────────

    private String buildFooter(MigrationReport r) {
        return "<footer class=\"site-footer\">SQL Migration Validator &nbsp;|&nbsp; " +
               r.getTotalQueries() + " queries &nbsp;|&nbsp; Generated " +
               r.getGeneratedAt() + "</footer>\n";
    }

    // ── JavaScript ─────────────────────────────────────────────────────────────

    private String buildScript() {
        return """
            <script>
            function toggleDetail(id) {
              var el = document.getElementById(id);
              if (!el) return;
              var visible = el.style.display !== 'none';
              el.style.display = visible ? 'none' : 'block';
              // Scroll into view
              if (!visible) el.scrollIntoView({ behavior:'smooth', block:'start' });
            }

            function filterTable() {
              var search  = document.getElementById('searchInput').value.toLowerCase();
              var verdict = document.getElementById('verdictFilter').value;
              var rows    = document.querySelectorAll('.data-row');
              rows.forEach(function(row) {
                var label   = (row.dataset.label  || '').toLowerCase();
                var sql     = (row.dataset.sql    || '').toLowerCase();
                var rowV    = (row.dataset.verdict|| '');
                var matchS  = !search  || label.includes(search) || sql.includes(search);
                var matchV  = !verdict || rowV === verdict;
                row.style.display = (matchS && matchV) ? '' : 'none';
              });
            }
            </script>
            """;
    }

    // ── CSS ────────────────────────────────────────────────────────────────────

    private String htmlHead() {
        return """
            <!DOCTYPE html>
            <html lang="en">
            <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width,initial-scale=1">
            <title>SQL Migration Validator Report</title>
            <style>
            /* ── Reset & base ─────────────────────────────────── */
            *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
            body {
              font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
              background: #0f1117;
              color: #e2e8f0;
              font-size: 14px;
              line-height: 1.6;
            }
            a { color: #63b3ed; }
            code { font-family: 'Cascadia Code', 'Fira Code', monospace; font-size: 12px; }
            pre  { font-family: 'Cascadia Code', 'Fira Code', monospace; font-size: 12px;
                   white-space: pre-wrap; word-break: break-word; }

            /* ── Header ───────────────────────────────────────── */
            .site-header {
              background: linear-gradient(135deg, #1a1f2e 0%, #16213e 100%);
              border-bottom: 2px solid #2d3748;
              padding: 18px 32px;
              position: sticky; top: 0; z-index: 100;
            }
            .header-inner { display: flex; align-items: center; justify-content: space-between; }
            .logo { display: flex; align-items: center; gap: 10px; font-size: 20px; font-weight: 700; }
            .logo-db {
              background: linear-gradient(135deg, #667eea, #764ba2);
              color: white;
              padding: 4px 10px; border-radius: 6px; font-size: 14px;
            }
            .logo-text { color: #e2e8f0; }
            .header-meta { color: #718096; font-size: 13px; }
            .header-meta .sep { margin: 0 8px; }

            /* ── Summary cards ────────────────────────────────── */
            .summary { padding: 28px 32px 12px; }
            .summary-grid {
              display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 16px;
            }
            .card {
              flex: 1; min-width: 120px;
              background: #1a1f2e;
              border: 1px solid #2d3748;
              border-radius: 12px;
              padding: 20px 16px;
              text-align: center;
              transition: transform .2s;
            }
            .card:hover { transform: translateY(-2px); }
            .card-icon  { font-size: 22px; margin-bottom: 6px; }
            .card-value { font-size: 32px; font-weight: 800; }
            .card-label { font-size: 11px; color: #718096; text-transform: uppercase; letter-spacing: 1px; }
            .card-pass  { border-color: #2f855a; } .card-pass  .card-value { color: #68d391; }
            .card-fail  { border-color: #c53030; } .card-fail  .card-value { color: #fc8181; }
            .card-error { border-color: #c05621; } .card-error .card-value { color: #f6ad55; }
            .card-rate  { border-color: #2b6cb0; } .card-rate  .card-value { color: #63b3ed; }
            .card-time  { border-color: #553c9a; } .card-time  .card-value { color: #b794f4; }
            .dsn-row    { color: #a0aec0; font-size: 12px; padding: 8px 0; }
            .dsn-label  { color: #718096; }
            .dsn-sep    { margin: 0 10px; color: #667eea; font-weight: bold; }

            /* ── Filter bar ───────────────────────────────────── */
            .filter-bar {
              display: flex; gap: 12px; padding: 12px 32px;
              background: #13171f; border-top: 1px solid #2d3748;
              border-bottom: 1px solid #2d3748;
            }
            .filter-bar input, .filter-bar select {
              background: #1a1f2e; border: 1px solid #2d3748;
              color: #e2e8f0; padding: 8px 14px; border-radius: 8px;
              outline: none; font-size: 13px;
            }
            .filter-bar input { flex: 1; }
            .filter-bar input:focus, .filter-bar select:focus { border-color: #667eea; }

            /* ── Summary table ────────────────────────────────── */
            .table-section { padding: 20px 32px; overflow-x: auto; }
            #mainTable {
              width: 100%; border-collapse: collapse;
              background: #1a1f2e; border-radius: 12px; overflow: hidden;
            }
            #mainTable th {
              background: #16213e; color: #a0aec0;
              font-size: 11px; text-transform: uppercase; letter-spacing: .8px;
              padding: 12px 14px; text-align: left; white-space: nowrap;
            }
            #mainTable td { padding: 11px 14px; border-bottom: 1px solid #2d3748; }
            #mainTable tbody tr:hover { background: #1e2535; }
            #mainTable tbody tr:last-child td { border-bottom: none; }
            .diff-cell { color: #fc8181; font-weight: 700; }
            .notes-count { color: #b794f4; }

            /* ── Badges ───────────────────────────────────────── */
            .badge {
              display: inline-block; padding: 2px 10px; border-radius: 20px;
              font-size: 11px; font-weight: 700; letter-spacing: .5px; text-transform: uppercase;
            }
            .badge-pass         { background: #1c4532; color: #68d391; border: 1px solid #2f855a; }
            .badge-data-diff    { background: #3d2700; color: #f6ad55; border: 1px solid #c05621; }
            .badge-row-count    { background: #3d1700; color: #feb2b2; border: 1px solid #c53030; }
            .badge-schema       { background: #2d1b69; color: #b794f4; border: 1px solid #553c9a; }
            .badge-mssql-error  { background: #2d0b0b; color: #fc8181; border: 1px solid #9b2c2c; }
            .badge-sybase-error { background: #1a1000; color: #fbd38d; border: 1px solid #975a16; }
            .badge-both-error   { background: #1a0011; color: #fbb6ce; border: 1px solid #97266d; }

            /* ── Detail panel toggle button ───────────────────── */
            .btn-detail {
              background: #2d3748; color: #e2e8f0; border: none;
              padding: 5px 12px; border-radius: 6px; cursor: pointer;
              font-size: 12px; transition: background .2s;
            }
            .btn-detail:hover { background: #4a5568; }

            /* ── Detail panels ────────────────────────────────── */
            .details { padding: 0 32px 40px; }
            .detail-panel {
              background: #1a1f2e; border: 1px solid #2d3748;
              border-radius: 12px; padding: 24px; margin-bottom: 20px;
            }
            .detail-panel h3 {
              font-size: 16px; margin-bottom: 18px;
              display: flex; align-items: center; gap: 10px;
            }
            .detail-panel h4 { font-size: 13px; color: #a0aec0; margin: 18px 0 8px; }

            /* ── SQL side-by-side grid ────────────────────────── */
            .sql-grid {
              display: grid; grid-template-columns: 1fr 1fr; gap: 16px;
              margin-bottom: 16px;
            }
            @media (max-width: 900px) { .sql-grid { grid-template-columns: 1fr; } }
            .sql-panel { background: #0d1117; border-radius: 8px; overflow: hidden; }
            .sql-panel-title {
              background: #161b22; padding: 8px 14px;
              font-size: 12px; color: #8b949e; font-weight: 600;
              border-bottom: 1px solid #30363d;
            }
            .sql-block { padding: 14px; color: #c9d1d9; max-height: 320px; overflow-y: auto; }
            .sql-block.converted { color: #79c0ff; }

            /* ── Conversion notes ─────────────────────────────── */
            .conv-notes {
              background: #13171f; border-left: 3px solid #667eea;
              padding: 12px 16px; border-radius: 0 8px 8px 0;
              margin-bottom: 14px; font-size: 12px; color: #a0aec0;
            }
            .conv-notes ul { margin: 6px 0 0 16px; }
            .conv-notes li { margin-bottom: 4px; }

            /* ── Error / warn boxes ───────────────────────────── */
            .error-box {
              background: #1a0011; border-left: 3px solid #fc8181;
              padding: 10px 14px; border-radius: 0 6px 6px 0;
              margin-bottom: 10px; color: #fc8181; font-size: 12px;
            }
            .error-box.mssql-err { border-left-color: #f6ad55; color: #f6ad55; }
            .schema-warn {
              background: #2d1b69; border-left: 3px solid #b794f4;
              padding: 8px 14px; margin-bottom: 8px; border-radius: 0 6px 6px 0;
              font-size: 12px; color: #e9d8fd;
            }
            .schema-info {
              background: #133055; border-left: 3px solid #63b3ed;
              padding: 8px 14px; margin-bottom: 8px; border-radius: 0 6px 6px 0;
              font-size: 12px; color: #bee3f8;
            }
            .all-match {
              background: #1c4532; border-left: 3px solid #68d391;
              padding: 10px 14px; border-radius: 0 6px 6px 0;
              color: #9ae6b4; font-size: 13px;
            }

            /* ── Cell diff table ──────────────────────────────── */
            .diff-table-wrap { overflow-x: auto; }
            .diff-table {
              width: 100%; border-collapse: collapse; font-size: 12px;
              background: #0d1117; border-radius: 8px; overflow: hidden;
            }
            .diff-table th {
              background: #161b22; color: #8b949e;
              padding: 8px 12px; text-align: left; font-size: 11px;
              text-transform: uppercase; letter-spacing: .7px;
            }
            .diff-table td { padding: 8px 12px; border-bottom: 1px solid #21262d; }
            .diff-row:hover { background: #1c1f26; }
            .val-sybase { color: #fc8181; background: rgba(252,129,129,.06); }
            .val-mssql  { color: #68d391; background: rgba(104,211,145,.06); }
            .truncated  { text-align: center; color: #718096; font-style: italic; padding: 14px; }

            /* ── Footer ───────────────────────────────────────── */
            .site-footer {
              text-align: center; padding: 20px 32px;
              border-top: 1px solid #2d3748;
              color: #4a5568; font-size: 12px;
            }

            /* ── Scrollbar ────────────────────────────────────── */
            ::-webkit-scrollbar { width: 6px; height: 6px; }
            ::-webkit-scrollbar-track { background: #1a1f2e; }
            ::-webkit-scrollbar-thumb { background: #4a5568; border-radius: 3px; }
            ::-webkit-scrollbar-thumb:hover { background: #718096; }
            </style>
            </head>
            """;
    }

    // ── Utility ────────────────────────────────────────────────────────────────

    private String verdictCss(String verdict) {
        return switch (verdict) {
            case "PASS"           -> "badge badge-pass";
            case "DATA_DIFF"      -> "badge badge-data-diff";
            case "ROW_COUNT_DIFF" -> "badge badge-row-count";
            case "SCHEMA_MISMATCH"-> "badge badge-schema";
            case "MSSQL_ERROR"    -> "badge badge-mssql-error";
            case "SYBASE_ERROR"   -> "badge badge-sybase-error";
            case "BOTH_ERROR"     -> "badge badge-both-error";
            default               -> "badge";
        };
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
                .replace("\"","&quot;").replace("'","&#39;");
    }

    private String abbrev(String s, int max) {
        if (s == null) return "";
        s = s.replaceAll("\\s+", " ").trim();
        return s.length() > max ? s.substring(0, max) + "…" : s;
    }
}
