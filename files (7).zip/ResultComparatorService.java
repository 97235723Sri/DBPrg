package com.sqlmigration.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * ResultComparatorService
 * ─────────────────────────────────────────────────────────────────────────────
 * Performs a deep, structured comparison of two QueryExecutionResult objects
 * (one from Sybase IQ, one from MS SQL Server) and produces a ComparisonResult.
 *
 * Comparison algorithm:
 *   Step 1 — Error check      : Did either DB throw an exception?
 *   Step 2 — Schema check     : Do column lists match (order-insensitive)?
 *   Step 3 — Row count check  : Same number of rows?
 *   Step 4 — Cell-level diff  : For every (row, column) pair, compare values.
 *                               Tolerances applied for numeric floating-point noise.
 */
@Service
@Slf4j
public class ResultComparatorService {

    /** Floating-point tolerance for numeric value comparison */
    private static final double NUMERIC_TOLERANCE = 1e-6;

    // ── Public API ─────────────────────────────────────────────────────────────

    public ComparisonResult compare(
            int                  queryNumber,
            String               queryLabel,
            String               originalSql,
            String               convertedSql,
            List<String>         conversionNotes,
            QueryExecutionResult sybaseResult,
            QueryExecutionResult mssqlResult) {

        ComparisonResult.Builder builder = ComparisonResult.builder()
            .queryNumber(queryNumber)
            .queryLabel(queryLabel)
            .originalSql(originalSql)
            .convertedSql(convertedSql)
            .sybaseResult(sybaseResult)
            .mssqlResult(mssqlResult)
            .conversionNotes(conversionNotes)
            .missingColumnsInMssql(new ArrayList<>())
            .extraColumnsInMssql(new ArrayList<>())
            .cellDiffs(new ArrayList<>());

        // ── Step 1: Error check ────────────────────────────────────────────────
        boolean sybaseErr = sybaseResult.getStatus() != QueryExecutionResult.Status.SUCCESS;
        boolean mssqlErr  = mssqlResult.getStatus()  != QueryExecutionResult.Status.SUCCESS;

        if (sybaseErr && mssqlErr) {
            return builder.verdict(ComparisonResult.Verdict.BOTH_ERROR)
                          .totalCellDiffs(0).build();
        }
        if (sybaseErr) {
            return builder.verdict(ComparisonResult.Verdict.SYBASE_ERROR)
                          .totalCellDiffs(0).build();
        }
        if (mssqlErr) {
            return builder.verdict(ComparisonResult.Verdict.MSSQL_ERROR)
                          .totalCellDiffs(0).build();
        }

        // ── Step 2: Schema / column check ─────────────────────────────────────
        List<String> sybaseCols = sybaseResult.getColumns();
        List<String> mssqlCols  = mssqlResult.getColumns();

        Set<String> onlyInSybase = new LinkedHashSet<>(sybaseCols);
        onlyInSybase.removeAll(mssqlCols);

        Set<String> onlyInMssql = new LinkedHashSet<>(mssqlCols);
        onlyInMssql.removeAll(sybaseCols);

        if (!onlyInSybase.isEmpty() || !onlyInMssql.isEmpty()) {
            log.warn("[{}] Schema mismatch. Only in Sybase: {} | Only in MSSQL: {}",
                queryLabel, onlyInSybase, onlyInMssql);
            return builder
                .verdict(ComparisonResult.Verdict.SCHEMA_MISMATCH)
                .missingColumnsInMssql(new ArrayList<>(onlyInSybase))
                .extraColumnsInMssql(new ArrayList<>(onlyInMssql))
                .totalCellDiffs(0)
                .build();
        }

        // ── Step 3: Row count check ────────────────────────────────────────────
        if (sybaseResult.getRowCount() != mssqlResult.getRowCount()) {
            log.warn("[{}] Row count mismatch: Sybase={} MSSQL={}",
                queryLabel, sybaseResult.getRowCount(), mssqlResult.getRowCount());
            return builder
                .verdict(ComparisonResult.Verdict.ROW_COUNT_DIFF)
                .totalCellDiffs(0)
                .build();
        }

        // ── Step 4: Cell-level comparison ─────────────────────────────────────
        List<CellDiff>            cellDiffs    = new ArrayList<>();
        List<Map<String, Object>> sybaseRows   = sybaseResult.getRows();
        List<Map<String, Object>> mssqlRows    = mssqlResult.getRows();

        // Use the shared (intersection) columns for comparison
        List<String> commonCols = new ArrayList<>(sybaseCols);
        commonCols.retainAll(mssqlCols);

        for (int rowIdx = 0; rowIdx < sybaseRows.size(); rowIdx++) {
            Map<String, Object> sRow = sybaseRows.get(rowIdx);
            Map<String, Object> mRow = mssqlRows.get(rowIdx);

            for (String col : commonCols) {
                String sVal = stringify(sRow.get(col));
                String mVal = stringify(mRow.get(col));

                if (!valuesMatch(sVal, mVal)) {
                    cellDiffs.add(CellDiff.builder()
                        .rowIndex(rowIdx + 1)       // 1-based for readability
                        .columnName(col)
                        .sybaseValue(sVal)
                        .mssqlValue(mVal)
                        .build());
                }
            }
        }

        ComparisonResult.Verdict verdict = cellDiffs.isEmpty()
            ? ComparisonResult.Verdict.PASS
            : ComparisonResult.Verdict.DATA_DIFF;

        log.info("[{}] Verdict: {} | Diffs: {}", queryLabel, verdict, cellDiffs.size());

        return builder
            .verdict(verdict)
            .cellDiffs(cellDiffs)
            .totalCellDiffs(cellDiffs.size())
            .build();
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private String stringify(Object val) {
        return val == null ? "NULL" : val.toString().trim();
    }

    /**
     * Value equality with numeric tolerance.
     * "1.0" and "1.000000" → equal.
     * "NULL" and null      → equal.
     */
    private boolean valuesMatch(String a, String b) {
        if (a.equals(b)) return true;

        // Both NULL
        if ("NULL".equalsIgnoreCase(a) && "NULL".equalsIgnoreCase(b)) return true;

        // Try numeric comparison
        try {
            double da = Double.parseDouble(a);
            double db = Double.parseDouble(b);
            return Math.abs(da - db) <= NUMERIC_TOLERANCE;
        } catch (NumberFormatException ignored) {
            // Not numeric — fall through to case-insensitive string compare
        }

        // Case-insensitive for string values (Sybase may return different case)
        return a.equalsIgnoreCase(b);
    }
}

// ── Supporting model classes ────────────────────────────────────────────────────

class CellDiff {
    private int    rowIndex;
    private String columnName;
    private String sybaseValue;
    private String mssqlValue;

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final CellDiff c = new CellDiff();
        public Builder rowIndex(int v)      { c.rowIndex = v;     return this; }
        public Builder columnName(String v) { c.columnName = v;   return this; }
        public Builder sybaseValue(String v){ c.sybaseValue = v;  return this; }
        public Builder mssqlValue(String v) { c.mssqlValue = v;   return this; }
        public CellDiff build()             { return c; }
    }

    public int    getRowIndex()    { return rowIndex;    }
    public String getColumnName()  { return columnName;  }
    public String getSybaseValue() { return sybaseValue; }
    public String getMssqlValue()  { return mssqlValue;  }
}

class ComparisonResult {

    public enum Verdict {
        PASS, SCHEMA_MISMATCH, ROW_COUNT_DIFF, DATA_DIFF,
        SYBASE_ERROR, MSSQL_ERROR, BOTH_ERROR
    }

    private int                  queryNumber;
    private String               queryLabel;
    private String               originalSql;
    private String               convertedSql;
    private QueryExecutionResult sybaseResult;
    private QueryExecutionResult mssqlResult;
    private Verdict              verdict;
    private List<String>         missingColumnsInMssql;
    private List<String>         extraColumnsInMssql;
    private List<CellDiff>       cellDiffs;
    private int                  totalCellDiffs;
    private List<String>         conversionNotes;

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private final ComparisonResult r = new ComparisonResult();
        public Builder queryNumber(int v)                         { r.queryNumber = v;             return this; }
        public Builder queryLabel(String v)                       { r.queryLabel = v;              return this; }
        public Builder originalSql(String v)                      { r.originalSql = v;             return this; }
        public Builder convertedSql(String v)                     { r.convertedSql = v;            return this; }
        public Builder sybaseResult(QueryExecutionResult v)       { r.sybaseResult = v;            return this; }
        public Builder mssqlResult(QueryExecutionResult v)        { r.mssqlResult = v;             return this; }
        public Builder verdict(Verdict v)                         { r.verdict = v;                 return this; }
        public Builder missingColumnsInMssql(List<String> v)      { r.missingColumnsInMssql = v;   return this; }
        public Builder extraColumnsInMssql(List<String> v)        { r.extraColumnsInMssql = v;     return this; }
        public Builder cellDiffs(List<CellDiff> v)                { r.cellDiffs = v;               return this; }
        public Builder totalCellDiffs(int v)                      { r.totalCellDiffs = v;          return this; }
        public Builder conversionNotes(List<String> v)            { r.conversionNotes = v;         return this; }
        public ComparisonResult build()                           { return r; }
    }

    // Getters
    public int                  getQueryNumber()          { return queryNumber;          }
    public String               getQueryLabel()           { return queryLabel;           }
    public String               getOriginalSql()          { return originalSql;          }
    public String               getConvertedSql()         { return convertedSql;         }
    public QueryExecutionResult getSybaseResult()         { return sybaseResult;         }
    public QueryExecutionResult getMssqlResult()          { return mssqlResult;          }
    public Verdict              getVerdict()              { return verdict;              }
    public List<String>         getMissingColumnsInMssql(){ return missingColumnsInMssql;}
    public List<String>         getExtraColumnsInMssql()  { return extraColumnsInMssql;  }
    public List<CellDiff>       getCellDiffs()            { return cellDiffs;            }
    public int                  getTotalCellDiffs()       { return totalCellDiffs;       }
    public List<String>         getConversionNotes()      { return conversionNotes;      }
}
