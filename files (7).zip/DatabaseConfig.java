package com.sqlmigration.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

/**
 * DatabaseConfig
 * ─────────────────────────────────────────────────────────────────────────────
 * Wires two independent HikariCP connection pools:
 *   1. sybaseDataSource  — Sybase IQ (jConnect JDBC driver)
 *   2. mssqlDataSource   — Microsoft SQL Server
 *
 * Each has its own JdbcTemplate bean for query execution.
 */
@Configuration
public class DatabaseConfig {

    // ── Sybase IQ ──────────────────────────────────────────────────────────────

    /**
     * Sybase IQ HikariCP config — reads spring.sybase.datasource.* from
     * application.yml automatically via @ConfigurationProperties.
     */
    @Bean
    @ConfigurationProperties(prefix = "spring.sybase.datasource.hikari")
    public HikariConfig sybaseHikariConfig() {
        HikariConfig cfg = new HikariConfig();
        // Defaults — overridden by YAML bindings above
        cfg.setDriverClassName("com.sybase.jdbc4.jdbc.SybDriver");
        cfg.setJdbcUrl("jdbc:sybase:Tds:SYBASE_HOST:5000/DUMMY_SYBASE_DB");
        cfg.setUsername("sybase_user");
        cfg.setPassword("sybase_pass");
        cfg.setPoolName("SybasePool");
        cfg.setMaximumPoolSize(10);
        cfg.setMinimumIdle(2);
        cfg.setConnectionTimeout(30_000);
        cfg.setIdleTimeout(600_000);
        cfg.setMaxLifetime(1_800_000);
        cfg.setConnectionTestQuery("SELECT 1");
        return cfg;
    }

    @Primary
    @Bean(name = "sybaseDataSource", destroyMethod = "close")
    public HikariDataSource sybaseDataSource() {
        /*
         * In a real deployment, populate the config via environment variables
         * or a secrets manager rather than hard-coded YAML:
         *
         *   SPRING_SYBASE_DATASOURCE_URL=jdbc:sybase:Tds:host:5000/db
         *   SPRING_SYBASE_DATASOURCE_USERNAME=...
         *   SPRING_SYBASE_DATASOURCE_PASSWORD=...
         */
        HikariConfig cfg = new HikariConfig();
        cfg.setDriverClassName("com.sybase.jdbc4.jdbc.SybDriver");
        cfg.setJdbcUrl(resolveProp("SYBASE_JDBC_URL",
                "jdbc:sybase:Tds:SYBASE_HOST:5000/DUMMY_SYBASE_DB"));
        cfg.setUsername(resolveProp("SYBASE_DB_USER", "sybase_user"));
        cfg.setPassword(resolveProp("SYBASE_DB_PASS", "sybase_pass"));
        cfg.setPoolName("SybasePool");
        cfg.setMaximumPoolSize(10);
        cfg.setMinimumIdle(2);
        cfg.setConnectionTimeout(30_000);
        cfg.setConnectionTestQuery("SELECT 1");
        return new HikariDataSource(cfg);
    }

    @Bean(name = "sybaseJdbcTemplate")
    public JdbcTemplate sybaseJdbcTemplate(
            @Qualifier("sybaseDataSource") DataSource ds) {
        return new JdbcTemplate(ds);
    }

    // ── MS SQL Server ──────────────────────────────────────────────────────────

    @Bean(name = "mssqlDataSource", destroyMethod = "close")
    public HikariDataSource mssqlDataSource() {
        HikariConfig cfg = new HikariConfig();
        cfg.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        cfg.setJdbcUrl(resolveProp("MSSQL_JDBC_URL",
                "jdbc:sqlserver://MSSQL_HOST:1433;"
                + "databaseName=DUMMY_MSSQL_DB;"
                + "encrypt=true;trustServerCertificate=true"));
        cfg.setUsername(resolveProp("MSSQL_DB_USER", "mssql_user"));
        cfg.setPassword(resolveProp("MSSQL_DB_PASS", "mssql_pass"));
        cfg.setPoolName("MsSqlPool");
        cfg.setMaximumPoolSize(10);
        cfg.setMinimumIdle(2);
        cfg.setConnectionTimeout(30_000);
        return new HikariDataSource(cfg);
    }

    @Bean(name = "mssqlJdbcTemplate")
    public JdbcTemplate mssqlJdbcTemplate(
            @Qualifier("mssqlDataSource") DataSource ds) {
        return new JdbcTemplate(ds);
    }

    // ── Helper ─────────────────────────────────────────────────────────────────

    /**
     * Resolves a value from environment variable first, falls back to default.
     * Allows secrets injection at runtime without changing source code.
     */
    private String resolveProp(String envVar, String defaultVal) {
        String v = System.getenv(envVar);
        return (v != null && !v.isBlank()) ? v : defaultVal;
    }
}
