package com.sqlmigration.runner;

import com.sqlmigration.service.MigrationOrchestrationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * MigrationRunner
 * ─────────────────────────────────────────────────────────────────────────────
 * Automatically triggers the migration validation on application start-up
 * when  migration.auto-run=true  (default: false).
 *
 * This lets you run the tool as a one-shot job:
 *   java -jar sql-migration-validator.jar --migration.auto-run=true
 *
 * Set to false when deploying as a persistent REST service.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class MigrationRunner implements CommandLineRunner {

    private final MigrationOrchestrationService orchestrationService;

    @Value("${migration.auto-run:false}")
    private boolean autoRun;

    @Override
    public void run(String... args) throws Exception {
        if (!autoRun) {
            log.info("Auto-run disabled. Use POST /api/migration/run to start.");
            return;
        }

        log.info("Auto-run enabled — starting migration validation …");
        try {
            String reportPath = orchestrationService.runMigration();
            log.info("════════════════════════════════════════════════════");
            log.info("  Migration complete!");
            log.info("  Report → {}", reportPath);
            log.info("  Open the HTML file in a browser to view the diff.");
            log.info("════════════════════════════════════════════════════");
        } catch (Exception ex) {
            log.error("Migration run failed: {}", ex.getMessage(), ex);
        }
    }
}
