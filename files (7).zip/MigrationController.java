package com.sqlmigration.controller;

import com.sqlmigration.service.MigrationOrchestrationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;

/**
 * MigrationController
 * ─────────────────────────────────────────────────────────────────────────────
 * REST endpoints to trigger and monitor the migration validation run.
 *
 * POST /api/migration/run        — Start migration (async, returns 202)
 * GET  /api/migration/status     — Poll run status
 * GET  /api/migration/run/sync   — Synchronous run (for testing)
 *
 * Typical usage:
 *   curl -X POST http://localhost:8080/api/migration/run
 *   curl       http://localhost:8080/api/migration/status
 */
@RestController
@RequestMapping("/api/migration")
@RequiredArgsConstructor
@Slf4j
public class MigrationController {

    private final MigrationOrchestrationService orchestrationService;

    // Simple state holders for the async run
    private final AtomicReference<String>  runStatus   = new AtomicReference<>("IDLE");
    private final AtomicReference<String>  reportPath  = new AtomicReference<>("");
    private final AtomicReference<String>  lastError   = new AtomicReference<>("");

    // ── POST /api/migration/run ────────────────────────────────────────────────

    @PostMapping("/run")
    public ResponseEntity<Map<String, Object>> startRun() {
        if ("RUNNING".equals(runStatus.get())) {
            return ResponseEntity.status(409)
                .body(Map.of("status", "RUNNING",
                             "message", "A migration run is already in progress."));
        }

        runStatus.set("RUNNING");
        reportPath.set("");
        lastError.set("");

        // Fire-and-forget async run
        CompletableFuture.runAsync(() -> {
            try {
                log.info("Async migration run starting …");
                String path = orchestrationService.runMigration();
                reportPath.set(path);
                runStatus.set("COMPLETED");
                log.info("Async migration run COMPLETED. Report: {}", path);
            } catch (Exception ex) {
                lastError.set(ex.getMessage());
                runStatus.set("FAILED");
                log.error("Async migration run FAILED: {}", ex.getMessage(), ex);
            }
        });

        return ResponseEntity.accepted()
            .body(Map.of(
                "status",  "RUNNING",
                "message", "Migration started. Poll /api/migration/status for progress.",
                "statusUrl", "/api/migration/status"
            ));
    }

    // ── GET /api/migration/status ──────────────────────────────────────────────

    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> status() {
        String s = runStatus.get();
        return ResponseEntity.ok(Map.of(
            "status",      s,
            "reportPath",  reportPath.get(),
            "lastError",   lastError.get()
        ));
    }

    // ── GET /api/migration/run/sync ────────────────────────────────────────────

    /**
     * Synchronous version — blocks until done.
     * Useful during development / CI pipelines.
     */
    @GetMapping("/run/sync")
    public ResponseEntity<Map<String, Object>> runSync() {
        try {
            log.info("Synchronous migration run starting …");
            String path = orchestrationService.runMigration();
            return ResponseEntity.ok(Map.of(
                "status",     "COMPLETED",
                "reportPath", path,
                "message",    "Report generated successfully."
            ));
        } catch (Exception ex) {
            log.error("Synchronous migration run failed", ex);
            return ResponseEntity.status(500)
                .body(Map.of(
                    "status",  "FAILED",
                    "message", ex.getMessage()
                ));
        }
    }

    // ── GET /api/migration/health ──────────────────────────────────────────────

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
            "status",  "UP",
            "version", "1.0.0",
            "name",    "SQL Migration Validator"
        ));
    }
}
