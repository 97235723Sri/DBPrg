package com.sqlmigration.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * SqlDialectConverterService
 * ─────────────────────────────────────────────────────────────────────────────
 * Converts Sybase IQ SQL to MS SQL Server (T-SQL) dialect using a chain of
 * regex-based rewrite rules.
 *
 * Rules applied in order (order matters — more specific rules first):
 *
 *   1.  LIST(col, sep)         → STRING_AGG(col, sep) WITHIN GROUP (ORDER BY col)
 *   2.  NVL(a, b)              → ISNULL(a, b)
 *   3.  IFNULL(a, b)           → ISNULL(a, b)
 *   4.  LOCATE(sub, str)       → CHARINDEX(sub, str)      [arg order swap]
 *   5.  SUBSTR(s, p, l)        → SUBSTRING(s, p, l)
 *   6.  SUBSTR(s, p)           → SUBSTRING(s, p, LEN(s))
 *   7.  LENGTH(x)              → LEN(x)
 *   8.  NOW()                  → GETDATE()
 *   9.  SYSDATE                → GETDATE()
 *  10.  TODAY()                → CAST(GETDATE() AS DATE)
 *  11.  DATEFORMAT(d, fmt)     → FORMAT(d, fmt)
 *  12.  MOD(a, b)              → (a % b)
 *  13.  TRIM(x)                → LTRIM(RTRIM(x))
 *  14.  || (string concat)     → +
 *  15.  DECODE(e,v1,r1,...)    → CASE WHEN e=v1 THEN r1 ... END
 *  16.  FETCH FIRST n ROWS ONLY → TOP n  (moved to after SELECT)
 *  17.  LIMIT n                → TOP n
 *  18.  REMAINDER(a, b)        → (a % b)
 *  19.  ADD_MONTHS(d, n)       → DATEADD(MONTH, n, d)
 *  20.  MONTHS_BETWEEN(d1,d2)  → DATEDIFF(MONTH, d2, d1)
 *  21.  TRUNC(d)               → CAST(d AS DATE)
 *  22.  TO_CHAR(d, fmt)        → FORMAT(d, fmt)
 *  23.  TO_DATE(s, fmt)        → TRY_CONVERT(DATE, s, 120)
 *  24.  INSTR(s, sub)          → CHARINDEX(sub, s)
 *  25.  LPAD(s, n, p)          → RIGHT(REPLICATE(p,n)+s, n)
 *  26.  RPAD(s, n, p)          → LEFT(s+REPLICATE(p,n), n)
 *  27.  INITCAP(s)             → (no direct T-SQL; keep with comment)
 *  28.  STRING data type       → VARCHAR(MAX)
 *  29.  LONG VARCHAR            → VARCHAR(MAX)
 *  30.  RECURSIVE keyword      → (removed; SQL Server CTEs are recursive by default)
 *  31.  WITH RECURSIVE         → WITH
 */
@Service
@Slf4j
public class SqlDialectConverterService {

    // Each Rule wraps one regex → replacement pair plus a description
    private record Rule(String description, Pattern pattern, String replacement) {}

    private final List<Rule> rules;

    public SqlDialectConverterService() {
        rules = buildRules();
        log.info("SqlDialectConverterService initialised with {} conversion rules", rules.size());
    }

    // ── Public API ─────────────────────────────────────────────────────────────

    /**
     * Convert a Sybase IQ SQL string to MS SQL T-SQL.
     *
     * @param sybaseSql  original SQL
     * @param notes      mutable list; conversion steps appended here
     * @return           converted SQL
     */
    public String convert(String sybaseSql, List<String> notes) {
        if (sybaseSql == null || sybaseSql.isBlank()) return sybaseSql;

        String sql = sybaseSql;

        for (Rule rule : rules) {
            String converted = applyRule(rule, sql);
            if (!converted.equals(sql)) {
                notes.add("Applied: " + rule.description());
                sql = converted;
                log.debug("Rule '{}' applied", rule.description());
            }
        }

        // Post-process: FETCH FIRST / LIMIT → TOP (requires SELECT rewrite)
        String afterTop = rewriteFetchFirstAndLimit(sql, notes);
        if (!afterTop.equals(sql)) sql = afterTop;

        // Post-process: DECODE( … ) → CASE WHEN … END
        String afterDecode = rewriteDecode(sql, notes);
        if (!afterDecode.equals(sql)) sql = afterDecode;

        return sql.trim();
    }

    // ── Rule builder ───────────────────────────────────────────────────────────

    private List<Rule> buildRules() {
        List<Rule> r = new ArrayList<>();
        int f = Pattern.CASE_INSENSITIVE | Pattern.DOTALL;

        // 1.  LIST aggregate  →  STRING_AGG
        //     LIST(col, ', ')         → STRING_AGG(col, ', ')
        //     LIST(col ORDER BY col, ', ')  — handled later in a separate method
        r.add(new Rule(
            "LIST() → STRING_AGG()",
            Pattern.compile("\\bLIST\\s*\\((.+?),\\s*('[^']*')\\s*\\)", f),
            "STRING_AGG($1, $2)"
        ));

        // 2.  NVL → ISNULL
        r.add(new Rule(
            "NVL() → ISNULL()",
            Pattern.compile("\\bNVL\\s*\\(", f),
            "ISNULL("
        ));

        // 3.  IFNULL → ISNULL
        r.add(new Rule(
            "IFNULL() → ISNULL()",
            Pattern.compile("\\bIFNULL\\s*\\(", f),
            "ISNULL("
        ));

        // 4.  LOCATE(substr, str) → CHARINDEX(substr, str)
        //     NOTE: arg order is the SAME between Sybase LOCATE and CHARINDEX here;
        //     Sybase LOCATE(sub, str) = CHARINDEX(sub, str) — they match.
        r.add(new Rule(
            "LOCATE() → CHARINDEX()",
            Pattern.compile("\\bLOCATE\\s*\\(", f),
            "CHARINDEX("
        ));

        // 5.  SUBSTR(s, p, l) → SUBSTRING(s, p, l)
        r.add(new Rule(
            "SUBSTR() → SUBSTRING()",
            Pattern.compile("\\bSUBSTR\\s*\\(", f),
            "SUBSTRING("
        ));

        // 6.  LENGTH(x) → LEN(x)
        r.add(new Rule(
            "LENGTH() → LEN()",
            Pattern.compile("\\bLENGTH\\s*\\(", f),
            "LEN("
        ));

        // 7.  NOW() → GETDATE()
        r.add(new Rule(
            "NOW() → GETDATE()",
            Pattern.compile("\\bNOW\\s*\\(\\s*\\)", f),
            "GETDATE()"
        ));

        // 8.  SYSDATE → GETDATE()
        r.add(new Rule(
            "SYSDATE → GETDATE()",
            Pattern.compile("\\bSYSDATE\\b", f),
            "GETDATE()"
        ));

        // 9.  TODAY() → CAST(GETDATE() AS DATE)
        r.add(new Rule(
            "TODAY() → CAST(GETDATE() AS DATE)",
            Pattern.compile("\\bTODAY\\s*\\(\\s*\\)", f),
            "CAST(GETDATE() AS DATE)"
        ));

        // 10. DATEFORMAT(date, fmt) → FORMAT(date, fmt)
        r.add(new Rule(
            "DATEFORMAT() → FORMAT()",
            Pattern.compile("\\bDATEFORMAT\\s*\\(", f),
            "FORMAT("
        ));

        // 11. MOD(a, b) → (a % b)
        r.add(new Rule(
            "MOD(a,b) → (a % b)",
            Pattern.compile("\\bMOD\\s*\\(([^,]+),([^)]+)\\)", f),
            "($1 % $2)"
        ));

        // 12. REMAINDER(a, b) → (a % b)
        r.add(new Rule(
            "REMAINDER(a,b) → (a % b)",
            Pattern.compile("\\bREMAINDER\\s*\\(([^,]+),([^)]+)\\)", f),
            "($1 % $2)"
        ));

        // 13. TRIM(x) → LTRIM(RTRIM(x))
        //     Only plain TRIM — not LTRIM/RTRIM (they work in both)
        r.add(new Rule(
            "TRIM() → LTRIM(RTRIM())",
            Pattern.compile("(?<!L)(?<!R)\\bTRIM\\s*\\(", f),
            "LTRIM(RTRIM("
        ));
        // Close the extra paren added for LTRIM(RTRIM(x))
        // This is tricky with regex; we handle it in post-processing via rewriteTrim()

        // 14. || → + (string concatenation)
        //     Must NOT replace inside string literals — simple approach: replace all ||
        r.add(new Rule(
            "|| → + (string concat)",
            Pattern.compile("\\|\\|", f),
            " + "
        ));

        // 15. ADD_MONTHS(date, n) → DATEADD(MONTH, n, date)
        r.add(new Rule(
            "ADD_MONTHS() → DATEADD(MONTH,...)",
            Pattern.compile("\\bADD_MONTHS\\s*\\(([^,]+),([^)]+)\\)", f),
            "DATEADD(MONTH, $2, $1)"
        ));

        // 16. MONTHS_BETWEEN(d1, d2) → DATEDIFF(MONTH, d2, d1)
        r.add(new Rule(
            "MONTHS_BETWEEN() → DATEDIFF(MONTH,...)",
            Pattern.compile("\\bMONTHS_BETWEEN\\s*\\(([^,]+),([^)]+)\\)", f),
            "DATEDIFF(MONTH, $2, $1)"
        ));

        // 17. TRUNC(date) → CAST(date AS DATE)  [date truncation only]
        r.add(new Rule(
            "TRUNC(date) → CAST(date AS DATE)",
            Pattern.compile("\\bTRUNC\\s*\\(([^)]+)\\)", f),
            "CAST($1 AS DATE)"
        ));

        // 18. TO_CHAR(date, fmt) → FORMAT(date, fmt)
        r.add(new Rule(
            "TO_CHAR() → FORMAT()",
            Pattern.compile("\\bTO_CHAR\\s*\\(", f),
            "FORMAT("
        ));

        // 19. TO_DATE(str, fmt) → TRY_CONVERT(DATE, str, 120)
        //     Simplified: ignores fmt, uses ISO style 120
        r.add(new Rule(
            "TO_DATE() → TRY_CONVERT(DATE,...)",
            Pattern.compile("\\bTO_DATE\\s*\\(([^,]+),([^)]+)\\)", f),
            "TRY_CONVERT(DATE, $1, 120)"
        ));

        // 20. INSTR(str, sub) → CHARINDEX(sub, str)  [arg order swap!]
        r.add(new Rule(
            "INSTR(str,sub) → CHARINDEX(sub,str)",
            Pattern.compile("\\bINSTR\\s*\\(([^,]+),([^)]+)\\)", f),
            "CHARINDEX($2, $1)"
        ));

        // 21. LPAD(str, n, pad) → RIGHT(REPLICATE(pad,n)+str, n)
        r.add(new Rule(
            "LPAD() → RIGHT(REPLICATE()+str,n)",
            Pattern.compile("\\bLPAD\\s*\\(([^,]+),([^,]+),([^)]+)\\)", f),
            "RIGHT(REPLICATE($3, $2) + $1, $2)"
        ));

        // 22. RPAD(str, n, pad) → LEFT(str+REPLICATE(pad,n), n)
        r.add(new Rule(
            "RPAD() → LEFT(str+REPLICATE(),n)",
            Pattern.compile("\\bRPAD\\s*\\(([^,]+),([^,]+),([^)]+)\\)", f),
            "LEFT($1 + REPLICATE($3, $2), $2)"
        ));

        // 23. STRING data type → VARCHAR(MAX)
        r.add(new Rule(
            "STRING type → VARCHAR(MAX)",
            Pattern.compile("\\bSTRING\\b(?!\\s*_AGG)", f),  // don't touch STRING_AGG
            "VARCHAR(MAX)"
        ));

        // 24. LONG VARCHAR → VARCHAR(MAX)
        r.add(new Rule(
            "LONG VARCHAR → VARCHAR(MAX)",
            Pattern.compile("\\bLONG\\s+VARCHAR\\b", f),
            "VARCHAR(MAX)"
        ));

        // 25. WITH RECURSIVE → WITH  (SQL Server CTEs are implicitly recursive)
        r.add(new Rule(
            "WITH RECURSIVE → WITH",
            Pattern.compile("\\bWITH\\s+RECURSIVE\\b", f),
            "WITH"
        ));

        // 26. INITCAP → annotate (no native T-SQL equivalent)
        r.add(new Rule(
            "INITCAP() — no T-SQL equivalent, left as-is with comment",
            Pattern.compile("\\bINITCAP\\s*\\(", f),
            "/*INITCAP-no-tsql-equiv*/ UPPER("
        ));

        // 27. STDEV (both DB support this — no change; kept for documentation)

        // 28. CEILING is same in both; FLOOR is same — no change needed

        return r;
    }

    // ── Regex apply helper ─────────────────────────────────────────────────────

    private String applyRule(Rule rule, String sql) {
        try {
            Matcher m = rule.pattern().matcher(sql);
            return m.replaceAll(rule.replacement());
        } catch (Exception ex) {
            log.warn("Rule '{}' failed: {}", rule.description(), ex.getMessage());
            return sql;
        }
    }

    // ── TRIM post-processor ────────────────────────────────────────────────────
    // After replacing TRIM( with LTRIM(RTRIM( we need to add a closing )
    // This is a parenthesis balancer for TRIM rewrites.
    public String fixTrimParens(String sql) {
        // Simple heuristic: for each LTRIM(RTRIM( we find, balance parens
        StringBuilder result = new StringBuilder();
        int i = 0;
        String target = "LTRIM(RTRIM(";
        while (i < sql.length()) {
            int pos = sql.indexOf(target, i);
            if (pos < 0) {
                result.append(sql, i, sql.length());
                break;
            }
            result.append(sql, i, pos);
            result.append(target);
            // find matching close paren for the inner RTRIM
            int depth  = 2; // two open parens from LTRIM( and RTRIM(
            int j      = pos + target.length();
            while (j < sql.length() && depth > 0) {
                char c = sql.charAt(j);
                if (c == '(') depth++;
                else if (c == ')') depth--;
                result.append(c);
                j++;
            }
            // depth should now be 1 — close the LTRIM(
            if (depth == 0) {
                // already closed RTRIM; add ) for LTRIM
                // The last char added was ')' which closed RTRIM, add one more for LTRIM
                // Actually: depth goes 2 -> 1 when first ) is hit, -> 0 on second )
                // So we need ONE more )
                result.append(')');
            }
            i = j;
        }
        return result.toString();
    }

    // ── FETCH FIRST / LIMIT rewriter ───────────────────────────────────────────

    /**
     * Converts:
     *   SELECT ... FROM ... FETCH FIRST 10 ROWS ONLY
     *   SELECT ... FROM ... LIMIT 10
     * to:
     *   SELECT TOP 10 ... FROM ...
     */
    private String rewriteFetchFirstAndLimit(String sql, List<String> notes) {
        // FETCH FIRST n ROWS ONLY
        Pattern fetchPattern = Pattern.compile(
            "^(\\s*SELECT\\s+)(.*?)(\\s+FETCH\\s+FIRST\\s+(\\d+)\\s+ROWS\\s+ONLY\\s*)$",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL
        );
        Matcher fm = fetchPattern.matcher(sql);
        if (fm.matches()) {
            String rewritten = fm.group(1) + "TOP " + fm.group(4).trim() + " " + fm.group(2);
            notes.add("FETCH FIRST " + fm.group(4).trim() + " ROWS ONLY → TOP " + fm.group(4).trim());
            return rewritten;
        }

        // LIMIT n
        Pattern limitPattern = Pattern.compile(
            "^(\\s*SELECT\\s+)(.*?)(\\s+LIMIT\\s+(\\d+)\\s*)$",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL
        );
        Matcher lm = limitPattern.matcher(sql);
        if (lm.matches()) {
            String rewritten = lm.group(1) + "TOP " + lm.group(4).trim() + " " + lm.group(2);
            notes.add("LIMIT " + lm.group(4).trim() + " → TOP " + lm.group(4).trim());
            return rewritten;
        }

        return sql;
    }

    // ── DECODE rewriter ────────────────────────────────────────────────────────

    /**
     * Rewrites:
     *   DECODE(expr, val1, res1, val2, res2, default)
     * to:
     *   CASE WHEN expr = val1 THEN res1
     *        WHEN expr = val2 THEN res2
     *        ELSE default
     *   END
     */
    public String rewriteDecode(String sql, List<String> notes) {
        Pattern p = Pattern.compile("\\bDECODE\\s*\\(", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(sql);
        if (!m.find()) return sql;

        StringBuilder out  = new StringBuilder();
        int           last = 0;
        m.reset();
        while (m.find()) {
            out.append(sql, last, m.start());
            int start = m.end();  // position right after DECODE(
            // extract everything inside the outer parens
            List<String> args  = extractArgs(sql, start - 1);
            int          end   = findMatchingParen(sql, start - 1);
            if (args == null || args.size() < 3) {
                // can't parse — leave as is
                out.append(sql, m.start(), end + 1);
            } else {
                out.append(decodeToCaseWhen(args));
                notes.add("DECODE() → CASE WHEN ... END");
            }
            last = end + 1;
        }
        out.append(sql, last, sql.length());
        return out.toString();
    }

    /** Build CASE WHEN from DECODE args list: [expr, v1, r1, v2, r2, ..., default] */
    private String decodeToCaseWhen(List<String> args) {
        String       expr  = args.get(0).trim();
        StringBuilder sb   = new StringBuilder("CASE");
        int          i     = 1;
        while (i + 1 < args.size()) {
            sb.append("\n       WHEN ").append(expr)
              .append(" = ").append(args.get(i).trim())
              .append(" THEN ").append(args.get(i + 1).trim());
            i += 2;
        }
        if (i < args.size()) {
            sb.append("\n       ELSE ").append(args.get(i).trim());
        }
        sb.append("\n  END");
        return sb.toString();
    }

    /** Extract comma-separated top-level args inside parens starting at parenPos */
    private List<String> extractArgs(String sql, int parenPos) {
        List<String> parts  = new ArrayList<>();
        int          depth  = 0;
        int          start  = parenPos + 1;
        StringBuilder cur   = new StringBuilder();
        for (int i = parenPos; i < sql.length(); i++) {
            char c = sql.charAt(i);
            if (c == '(')      { depth++; if (depth > 1) cur.append(c); }
            else if (c == ')') { depth--; if (depth == 0) { parts.add(cur.toString()); return parts; }
                                           else cur.append(c); }
            else if (c == ',' && depth == 1) { parts.add(cur.toString()); cur = new StringBuilder(); }
            else if (depth >= 1) cur.append(c);
        }
        return parts;
    }

    /** Find the closing paren that matches the open paren at pos */
    private int findMatchingParen(String sql, int pos) {
        int depth = 0;
        for (int i = pos; i < sql.length(); i++) {
            if (sql.charAt(i) == '(') depth++;
            else if (sql.charAt(i) == ')') { depth--; if (depth == 0) return i; }
        }
        return sql.length() - 1;
    }
}
