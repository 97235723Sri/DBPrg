package com.sqlmigration.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * MigrationOrchestrationService
 * ─────────────────────────────────────────────────────────────────────────────
 * Top-level coordinator:
 *  1. Loads and parses queries.sql into individual query strings
 *  2. Submits each query as a parallel task to the thread pool
 *  3. Each task:
 *       a. Execute original SQL on Sybase IQ
 *       b. Convert SQL dialect
 *       c. Execute converted SQL on MS SQL Server
 *       d. Compare results
 *  4. Collects all ComparisonResult objects
 *  5. Generates summary MigrationReport
 *  6. Triggers HTML report generation
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class MigrationOrchestrationService {

    private final QueryExecutorService      executorService;
    private final SqlDialectConverterService converterService;
    private final ResultComparatorService   comparatorService;
    private final HtmlReportGeneratorService reportGeneratorService;

    @Value("${migration.queries-file}")
    private Resource queriesFile;

    @Value("${migration.parallel-threads:10}")
    private int parallelThreads;

    @Value("${migration.report-output-dir:./reports}")
    private String reportOutputDir;

    // ── Run migration ──────────────────────────────────────────────────────────

    /**
     * Entry point — loads all queries, runs them in parallel, generates report.
     *
     * @return path to the generated HTML report
     */
    public String runMigration() throws IOException, InterruptedException {
        log.info("═══════════════════════════════════════════════════════");
        log.info("  SQL Migration Validator — starting run");
        log.info("  Threads : {}", parallelThreads);
        log.info("═══════════════════════════════════════════════════════");

        long runStart = System.currentTimeMillis();

        // ── 1. Load queries ────────────────────────────────────────────────────
        List<String> rawQueries = loadQueries();
        log.info("Loaded {} queries from {}", rawQueries.size(), queriesFile.getFilename());

        // ── 2. Build tasks ─────────────────────────────────────────────────────
        List<QueryTask> tasks = new ArrayList<>();
        for (int i = 0; i < rawQueries.size(); i++) {
            tasks.add(QueryTask.builder()
                .queryNumber(i + 1)
                .queryLabel(String.format("Q%03d", i + 1))
                .originalSql(rawQueries.get(i))
                .build());
        }

        // ── 3. Execute in parallel ─────────────────────────────────────────────
        ExecutorService pool        = Executors.newFixedThreadPool(parallelThreads);
        List<Future<ComparisonResult>> futures = new ArrayList<>();
        AtomicInteger                  done    = new AtomicInteger(0);

        for (QueryTask task : tasks) {
            futures.add(pool.submit(() -> processQuery(task, done, rawQueries.size())));
        }

        List<ComparisonResult> results = new ArrayList<>();
        for (Future<ComparisonResult> f : futures) {
            try {
                results.add(f.get());
            } catch (ExecutionException ex) {
                log.error("Unexpected execution exception: {}", ex.getCause().getMessage(), ex);
            }
        }

        pool.shutdown();
        pool.awaitTermination(10, TimeUnit.MINUTES);

        // ── 4. Sort results by query number ────────────────────────────────────
        results.sort(Comparator.comparingInt(ComparisonResult::getQueryNumber));

        // ── 5. Build summary report ────────────────────────────────────────────
        long   totalMs = System.currentTimeMillis() - runStart;
        long   passed  = results.stream().filter(r -> r.getVerdict() == ComparisonResult.Verdict.PASS).count();
        long   errors  = results.stream().filter(r ->
                             r.getVerdict() == ComparisonResult.Verdict.SYBASE_ERROR ||
                             r.getVerdict() == ComparisonResult.Verdict.MSSQL_ERROR  ||
                             r.getVerdict() == ComparisonResult.Verdict.BOTH_ERROR).count();
        long   failed  = results.size() - passed - errors;

        MigrationReport report = MigrationReport.builder()
            .generatedAt(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))
            .sybaseDsn("DUMMY_SYBASE_DB @ SYBASE_HOST:5000")
            .mssqlDsn("DUMMY_MSSQL_DB @ MSSQL_HOST:1433")
            .totalQueries(results.size())
            .passed((int) passed)
            .failed((int) failed)
            .errors((int) errors)
            .totalRunTimeMs(totalMs)
            .results(results)
            .build();

        log.info("═══════════════════════════════════════════════════════");
        log.info("  Run complete in {}ms", totalMs);
        log.info("  PASS={} | FAIL={} | ERROR={}", passed, failed, errors);
        log.info("═══════════════════════════════════════════════════════");

        // ── 6. Generate HTML report ────────────────────────────────────────────
        return reportGeneratorService.generateHtmlReport(report, reportOutputDir);
    }

    // ── Per-query processing ───────────────────────────────────────────────────

    private ComparisonResult processQuery(QueryTask task, AtomicInteger done, int total) {
        String label  = task.getQueryLabel();
        String origSql = task.getOriginalSql();

        log.debug("[{}] Starting …", label);

        // a. Dialect conversion
        List<String> notes        = new ArrayList<>();
        String       convertedSql = converterService.convert(origSql, notes);
        // Fix TRIM parens introduced by the converter
        convertedSql = converterService.fixTrimParens(convertedSql);

        // b. Execute on Sybase IQ (original SQL)
        QueryExecutionResult sybaseResult = executorService.executeOnSybase(origSql);

        // c. Execute on MS SQL (converted SQL)
        QueryExecutionResult mssqlResult  = executorService.executeOnMssql(convertedSql);

        // d. Compare
        ComparisonResult result = comparatorService.compare(
            task.getQueryNumber(), label,
            origSql, convertedSql,
            notes,
            sybaseResult, mssqlResult
        );

        int n = done.incrementAndGet();
        log.info("[{}/{}] {} — {}", n, total, label, result.getVerdict());
        return result;
    }

    // ── Query loader ───────────────────────────────────────────────────────────

    /**
     * Reads queries.sql and splits on ';' (semicolons on their own line or
     * at the end of a statement).  Comment lines (--) and blank lines ignored.
     */
    private List<String> loadQueries() throws IOException {
        String raw = new String(queriesFile.getInputStream().readAllBytes(),
                                StandardCharsets.UTF_8);

        // Remove block comments /* ... */
        raw = raw.replaceAll("/\\*.*?\\*/", " ");

        // Split on semicolons
        String[] parts = raw.split(";");
        List<String> queries = new ArrayList<>();

        for (String part : parts) {
            // Remove single-line comments
            String cleaned = Arrays.stream(part.split("\n"))
                .filter(line -> !line.trim().startsWith("--"))
                .collect(Collectors.joining("\n"))
                .trim();

            if (!cleaned.isBlank()) {
                queries.add(cleaned);
            }
        }

        log.info("Parsed {} non-empty queries", queries.size());
        return queries;
    }
}

// ── QueryTask inner model ──────────────────────────────────────────────────────

class QueryTask {
    private int    queryNumber;
    private String queryLabel;
    private String originalSql;
    private String convertedSql;

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final QueryTask t = new QueryTask();
        public Builder queryNumber(int v)   { t.queryNumber = v;  return this; }
        public Builder queryLabel(String v) { t.queryLabel = v;   return this; }
        public Builder originalSql(String v){ t.originalSql = v;  return this; }
        public QueryTask build()            { return t; }
    }

    public int    getQueryNumber()  { return queryNumber;  }
    public String getQueryLabel()   { return queryLabel;   }
    public String getOriginalSql()  { return originalSql;  }
}

// ── MigrationReport model ──────────────────────────────────────────────────────

class MigrationReport {
    private String                  generatedAt;
    private String                  sybaseDsn;
    private String                  mssqlDsn;
    private int                     totalQueries;
    private int                     passed;
    private int                     failed;
    private int                     errors;
    private long                    totalRunTimeMs;
    private List<ComparisonResult>  results;

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final MigrationReport r = new MigrationReport();
        public Builder generatedAt(String v)                   { r.generatedAt = v;    return this; }
        public Builder sybaseDsn(String v)                     { r.sybaseDsn = v;      return this; }
        public Builder mssqlDsn(String v)                      { r.mssqlDsn = v;       return this; }
        public Builder totalQueries(int v)                     { r.totalQueries = v;   return this; }
        public Builder passed(int v)                           { r.passed = v;         return this; }
        public Builder failed(int v)                           { r.failed = v;         return this; }
        public Builder errors(int v)                           { r.errors = v;         return this; }
        public Builder totalRunTimeMs(long v)                  { r.totalRunTimeMs = v; return this; }
        public Builder results(List<ComparisonResult> v)       { r.results = v;        return this; }
        public MigrationReport build()                         { return r; }
    }

    public String                 getGeneratedAt()   { return generatedAt;   }
    public String                 getSybaseDsn()     { return sybaseDsn;     }
    public String                 getMssqlDsn()      { return mssqlDsn;      }
    public int                    getTotalQueries()   { return totalQueries;  }
    public int                    getPassed()         { return passed;        }
    public int                    getFailed()         { return failed;        }
    public int                    getErrors()         { return errors;        }
    public long                   getTotalRunTimeMs() { return totalRunTimeMs;}
    public List<ComparisonResult> getResults()        { return results;       }
}
