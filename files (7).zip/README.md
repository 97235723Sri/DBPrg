# SQL Migration Validator — Sybase IQ → MS SQL Server

A Spring Boot tool that **runs 100 SQL queries on both Sybase IQ and MS SQL Server in parallel**, converts the Sybase dialect automatically, compares every result set, and generates a rich HTML diff report.

---

## Architecture

```
queries.sql (100 queries)
       │
       ▼
MigrationOrchestrationService
       │
       ├──► SqlDialectConverterService   (30+ regex rewrite rules)
       │           │
       │           └──► convertedSQL
       │
       ├──► QueryExecutorService::executeOnSybase(originalSQL)
       │           └──► QueryExecutionResult (rows, cols, timing, errors)
       │
       ├──► QueryExecutorService::executeOnMssql(convertedSQL)
       │           └──► QueryExecutionResult (rows, cols, timing, errors)
       │
       ├──► ResultComparatorService
       │       Step 1: Error check (did either DB fail?)
       │       Step 2: Schema check (column names match?)
       │       Step 3: Row count check
       │       Step 4: Cell-level diff (with numeric tolerance)
       │           └──► ComparisonResult (verdict + list of CellDiff)
       │
       └──► HtmlReportGeneratorService
               └──► migration-report-YYYY-MM-DD_HH-mm-ss.html
```

All 100 query pairs run **concurrently** (configurable thread pool, default 10).

---

## Dialect Conversion Rules (30+)

| Sybase IQ | MS SQL Server (T-SQL) |
|---|---|
| `NVL(a, b)` | `ISNULL(a, b)` |
| `IFNULL(a, b)` | `ISNULL(a, b)` |
| `LIST(col, sep)` | `STRING_AGG(col, sep)` |
| `\|\|` | `+` |
| `NOW()` | `GETDATE()` |
| `SYSDATE` | `GETDATE()` |
| `TODAY()` | `CAST(GETDATE() AS DATE)` |
| `DATEFORMAT(d, fmt)` | `FORMAT(d, fmt)` |
| `LENGTH(x)` | `LEN(x)` |
| `LOCATE(sub, str)` | `CHARINDEX(sub, str)` |
| `SUBSTR(s, p, l)` | `SUBSTRING(s, p, l)` |
| `MOD(a, b)` | `(a % b)` |
| `TRIM(x)` | `LTRIM(RTRIM(x))` |
| `DECODE(e, v1, r1, …)` | `CASE WHEN e=v1 THEN r1 … END` |
| `ADD_MONTHS(d, n)` | `DATEADD(MONTH, n, d)` |
| `MONTHS_BETWEEN(d1, d2)` | `DATEDIFF(MONTH, d2, d1)` |
| `TRUNC(date)` | `CAST(date AS DATE)` |
| `TO_CHAR(d, fmt)` | `FORMAT(d, fmt)` |
| `TO_DATE(s, fmt)` | `TRY_CONVERT(DATE, s, 120)` |
| `INSTR(s, sub)` | `CHARINDEX(sub, s)` |
| `LPAD(s, n, p)` | `RIGHT(REPLICATE(p,n)+s, n)` |
| `RPAD(s, n, p)` | `LEFT(s+REPLICATE(p,n), n)` |
| `STRING` type | `VARCHAR(MAX)` |
| `LONG VARCHAR` | `VARCHAR(MAX)` |
| `WITH RECURSIVE` | `WITH` |
| `FETCH FIRST n ROWS ONLY` | `TOP n` |
| `LIMIT n` | `TOP n` |

---

## Report Verdicts

| Verdict | Meaning |
|---|---|
| ✅ `PASS` | Rows, columns and all values match |
| 🟡 `DATA_DIFF` | Same schema/rows but ≥1 cell values differ |
| 🟠 `ROW_COUNT_DIFF` | Same schema, different number of rows |
| 🟣 `SCHEMA_MISMATCH` | Column names or count differ |
| 🔴 `MSSQL_ERROR` | MS SQL threw an exception |
| 🟤 `SYBASE_ERROR` | Sybase IQ threw an exception |
| ⚫ `BOTH_ERROR` | Both databases failed |

---

## Prerequisites

| Requirement | Version |
|---|---|
| Java | 17+ |
| Maven | 3.8+ |
| Sybase jConnect JAR | 7.07 (`jconn4.jar`) |
| Sybase IQ | 16.x / SAP IQ |
| SQL Server | 2016+ / Azure SQL |

### Install jConnect (Sybase JDBC driver)

Download `jconn4.jar` from SAP's software portal, then:

```bash
mkdir -p lib
cp /path/to/jconn4.jar lib/

mvn install:install-file \
  -Dfile=lib/jconn4.jar \
  -DgroupId=com.sybase \
  -DartifactId=jconn4 \
  -Dversion=7.07 \
  -Dpackaging=jar
```

---

## Configuration

Edit `src/main/resources/application.yml` **or** pass environment variables:

```yaml
spring:
  sybase:
    datasource:
      url:      jdbc:sybase:Tds:YOUR_SYBASE_HOST:5000/YOUR_DB
      username: sybase_user
      password: sybase_pass

  mssql:
    datasource:
      url:      jdbc:sqlserver://YOUR_MSSQL_HOST:1433;databaseName=YOUR_DB;encrypt=true;trustServerCertificate=true
      username: mssql_user
      password: mssql_pass

migration:
  parallel-threads:      10     # concurrent query pairs
  query-timeout-seconds: 120    # per-query timeout
  max-rows-to-compare:   10000  # row cap to avoid OOM
  report-output-dir:     ./reports
  auto-run:              false  # true = run on startup
```

**Using environment variables (recommended for secrets):**
```bash
export SYBASE_JDBC_URL="jdbc:sybase:Tds:host:5000/db"
export SYBASE_DB_USER="user"
export SYBASE_DB_PASS="secret"
export MSSQL_JDBC_URL="jdbc:sqlserver://host:1433;databaseName=db;..."
export MSSQL_DB_USER="user"
export MSSQL_DB_PASS="secret"
```

---

## Build & Run

### Option 1 — REST API mode (default)

```bash
mvn clean package -DskipTests
java -jar target/sql-migration-validator-1.0.0.jar

# Trigger migration via API
curl -X POST http://localhost:8080/api/migration/run

# Poll status
curl http://localhost:8080/api/migration/status

# Or run synchronously (waits for completion)
curl http://localhost:8080/api/migration/run/sync
```

### Option 2 — One-shot batch mode

```bash
java -jar target/sql-migration-validator-1.0.0.jar \
     --migration.auto-run=true
```

---

## Queries File Format

`src/main/resources/queries/queries.sql`

- Each query separated by `;` on its own line (or end of statement)
- `--` single-line comments supported (stripped before parsing)
- `/* … */` block comments also stripped
- Queries are assigned labels Q001, Q002 … automatically

---

## REST API Reference

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/migration/run` | Start async run (202 Accepted) |
| `GET` | `/api/migration/status` | Poll run status |
| `GET` | `/api/migration/run/sync` | Synchronous run (blocks) |
| `GET` | `/api/migration/health` | Health check |

---

## Project Structure

```
sql-migration-validator/
├── pom.xml
├── lib/
│   └── jconn4.jar                          ← Sybase JDBC (manual add)
├── src/main/java/com/sqlmigration/
│   ├── SqlMigrationApplication.java        ← Spring Boot entry point
│   ├── config/
│   │   └── DatabaseConfig.java             ← Two HikariCP DataSources
│   ├── service/
│   │   ├── SqlDialectConverterService.java ← 30+ Sybase→MSSQL rules
│   │   ├── QueryExecutorService.java       ← Runs SQL on both DBs
│   │   ├── ResultComparatorService.java    ← Deep result comparison
│   │   ├── HtmlReportGeneratorService.java ← HTML diff report
│   │   └── MigrationOrchestrationService  ← Coordinates the full flow
│   ├── controller/
│   │   └── MigrationController.java        ← REST API
│   └── runner/
│       └── MigrationRunner.java            ← Optional auto-run on startup
└── src/main/resources/
    ├── application.yml
    └── queries/
        └── queries.sql                     ← 100 Sybase IQ queries
```
